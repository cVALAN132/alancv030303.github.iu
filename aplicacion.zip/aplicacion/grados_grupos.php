<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener todos los grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                    <h6>Grados y Grupos</h6>
                    <div>
                        <button class="btn btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#nuevoGradoModal">
                            <i class="fas fa-plus"></i> Nuevo Grado
                        </button>
                        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#nuevoGrupoModal">
                            <i class="fas fa-plus"></i> Nuevo Grupo
                        </button>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="row p-4">
                        <?php while ($grado = mysqli_fetch_assoc($resultado_grados)) { 
                            // Obtener grupos del grado
                            $query_grupos = "SELECT g.*, COUNT(a.id_alumno) as total_alumnos 
                                           FROM grupos g 
                                           LEFT JOIN alumnos a ON g.id_grupo = a.id_grupo 
                                           WHERE g.id_grado = ? 
                                           GROUP BY g.id_grupo";
                            $stmt = mysqli_prepare($conexion, $query_grupos);
                            mysqli_stmt_bind_param($stmt, "i", $grado['id_grado']);
                            mysqli_stmt_execute($stmt);
                            $resultado_grupos = mysqli_stmt_get_result($stmt);
                        ?>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0"><?php echo $grado['nombre']; ?></h5>
                                        <div>
                                            <button class="btn btn-light btn-sm" onclick="editarGrado(<?php echo $grado['id_grado']; ?>, '<?php echo $grado['nombre']; ?>')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm" onclick="eliminarGrado(<?php echo $grado['id_grado']; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <?php while ($grupo = mysqli_fetch_assoc($resultado_grupos)) { ?>
                                            <div class="grupo-item mb-2 d-flex justify-content-between align-items-center">
                                                <a href="ver_grupo.php?id=<?php echo $grupo['id_grupo']; ?>" 
                                                   class="btn btn-outline-primary text-start flex-grow-1 me-2">
                                                    <i class="fas fa-users me-2"></i>
                                                    <?php echo $grupo['nombre']; ?>
                                                    <span class="badge bg-secondary float-end">
                                                        <?php echo $grupo['total_alumnos']; ?> alumnos
                                                    </span>
                                                </a>
                                                <div class="btn-group">
                                                    <button class="btn btn-warning btn-sm" 
                                                            onclick="editarGrupo(<?php echo $grupo['id_grupo']; ?>, '<?php echo $grupo['nombre']; ?>', <?php echo $grupo['id_grado']; ?>)">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-danger btn-sm" 
                                                            onclick="eliminarGrupo(<?php echo $grupo['id_grupo']; ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nuevo Grado -->
<div class="modal fade" id="nuevoGradoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nuevo Grado</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevoGrado">
                    <div class="mb-3">
                        <label class="form-label">Nombre del Grado</label>
                        <input type="text" class="form-control" name="nombre" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nuevo Grupo -->
<div class="modal fade" id="nuevoGrupoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nuevo Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevoGrupo">
                    <div class="mb-3">
                        <label class="form-label">Grado</label>
                        <select class="form-select" name="id_grado" required>
                            <option value="">Seleccionar Grado</option>
                            <?php 
                            mysqli_data_seek($resultado_grados, 0);
                            while ($grado = mysqli_fetch_assoc($resultado_grados)) { 
                            ?>
                                <option value="<?php echo $grado['id_grado']; ?>">
                                    <?php echo $grado['nombre']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre del Grupo</label>
                        <input type="text" class="form-control" name="nombre" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Grado -->
<div class="modal fade" id="editarGradoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Grado</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarGrado">
                    <input type="hidden" name="id_grado" id="edit_id_grado">
                    <div class="mb-3">
                        <label class="form-label">Nombre del Grado</label>
                        <input type="text" class="form-control" name="nombre" id="edit_nombre_grado" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Grupo -->
<div class="modal fade" id="editarGrupoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarGrupo">
                    <input type="hidden" name="id_grupo" id="edit_id_grupo">
                    <div class="mb-3">
                        <label class="form-label">Grado</label>
                        <select class="form-select" name="id_grado" id="edit_grupo_id_grado" required>
                            <?php 
                            mysqli_data_seek($resultado_grados, 0);
                            while ($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                <option value="<?php echo $grado['id_grado']; ?>">
                                    <?php echo $grado['nombre']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre del Grupo</label>
                        <input type="text" class="form-control" name="nombre" id="edit_nombre_grupo" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Funciones para editar
function editarGrado(id_grado, nombre) {
    $('#edit_id_grado').val(id_grado);
    $('#edit_nombre_grado').val(nombre);
    $('#editarGradoModal').modal('show');
}

function editarGrupo(id_grupo, nombre, id_grado) {
    $('#edit_id_grupo').val(id_grupo);
    $('#edit_nombre_grupo').val(nombre);
    $('#edit_grupo_id_grado').val(id_grado);
    $('#editarGrupoModal').modal('show');
}

// Funciones para eliminar
function eliminarGrado(id_grado) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Se eliminarán también todos los grupos asociados",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'actions/grados/eliminar_grado.php',
                method: 'POST',
                data: { id_grado: id_grado },
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Eliminado!',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message
                        });
                    }
                }
            });
        }
    });
}

function eliminarGrupo(id_grupo) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción no se puede deshacer",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'actions/grupos/eliminar_grupo.php',
                method: 'POST',
                data: { id_grupo: id_grupo },
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Eliminado!',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message
                        });
                    }
                }
            });
        }
    });
}

$(document).ready(function() {
    // Manejar formulario de nuevo grado
    $('#formNuevoGrado').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/grados/crear_grado.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });

    // Manejar formulario de nuevo grupo
    $('#formNuevoGrupo').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/grupos/crear_grupo.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });

    // Manejar formulario de editar grado
    $('#formEditarGrado').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/grados/editar_grado.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                $('#editarGradoModal').modal('hide');
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });

    // Manejar formulario de editar grupo
    $('#formEditarGrupo').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/grupos/editar_grupo.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                $('#editarGrupoModal').modal('hide');
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?> 