<?php
require_once 'includes/header.php';
require_once 'config/conexion.php';

// Obtener el grado y grupo seleccionados
$id_grado = isset($_GET['grado']) ? $_GET['grado'] : null;
$id_grupo = isset($_GET['grupo']) ? $_GET['grupo'] : null;
$periodo = isset($_GET['periodo']) ? $_GET['periodo'] : 1;

// Obtener lista de grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);

// Obtener grupos si se seleccionó un grado
$resultado_grupos = null;
if($id_grado) {
    $query_grupos = "SELECT * FROM grupos WHERE id_grado = $id_grado ORDER BY nombre";
    $resultado_grupos = mysqli_query($conexion, $query_grupos);
}

// Obtener alumnos si se seleccionó un grupo
$resultado_alumnos = null;
if($id_grupo) {
    $query_alumnos = "SELECT a.id_alumno, a.nombre, a.email,
                      (SELECT fecha_envio 
                       FROM boletas_enviadas be 
                       WHERE be.id_alumno = a.id_alumno 
                       AND be.periodo = '$periodo') as fecha_envio
                      FROM alumnos a 
                      WHERE a.id_grupo = $id_grupo 
                      ORDER BY a.nombre";
    $resultado_alumnos = mysqli_query($conexion, $query_alumnos);
}
?>

<div class="container py-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-envelope me-2"></i>
                        Enviar Boletas por Correo
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Filtros -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="form-label">Grado</label>
                            <select class="form-select" id="selectGrado">
                                <option value="">Seleccionar Grado</option>
                                <?php while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                    <option value="<?php echo $grado['id_grado']; ?>" 
                                            <?php echo ($id_grado == $grado['id_grado']) ? 'selected' : ''; ?>>
                                        <?php echo $grado['nombre']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Grupo</label>
                            <select class="form-select" id="selectGrupo">
                                <option value="">Seleccionar Grupo</option>
                                <?php 
                                if($resultado_grupos) {
                                    while($grupo = mysqli_fetch_assoc($resultado_grupos)) { ?>
                                        <option value="<?php echo $grupo['id_grupo']; ?>"
                                                <?php echo ($id_grupo == $grupo['id_grupo']) ? 'selected' : ''; ?>>
                                            <?php echo $grupo['nombre']; ?>
                                        </option>
                                <?php }
                                } ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Periodo</label>
                            <select class="form-select" id="selectPeriodo">
                                <option value="1" <?php echo $periodo == 1 ? 'selected' : ''; ?>>Primer Periodo</option>
                                <option value="2" <?php echo $periodo == 2 ? 'selected' : ''; ?>>Segundo Periodo</option>
                                <option value="3" <?php echo $periodo == 3 ? 'selected' : ''; ?>>Tercer Periodo</option>
                                <option value="final" <?php echo $periodo == 'final' ? 'selected' : ''; ?>>Boleta Final</option>
                            </select>
                        </div>
                    </div>

                    <!-- Archivo y mensaje -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Archivo de Boleta</label>
                                <input type="file" class="form-control" id="boletaFile" accept=".pdf,.doc,.docx">
                                <small class="text-muted">Formatos permitidos: PDF, DOC, DOCX</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Mensaje del Correo</label>
                                <textarea class="form-control" id="mensajeCorreo" rows="3">Estimado padre de familia,

Adjunto encontrará la boleta de calificaciones de su hijo(a).

Saludos cordiales.</textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Tabla de alumnos -->
                    <?php if($id_grupo && $resultado_alumnos && mysqli_num_rows($resultado_alumnos) > 0) { ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" id="selectAll" class="form-check-input">
                                        </th>
                                        <th>Alumno</th>
                                        <th>Correo</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($alumno = mysqli_fetch_assoc($resultado_alumnos)) { ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="form-check-input alumno-check" 
                                                       value="<?php echo $alumno['id_alumno']; ?>"
                                                       <?php echo empty($alumno['email']) || !empty($alumno['fecha_envio']) ? 'disabled' : ''; ?>>
                                            </td>
                                            <td><?php echo $alumno['nombre']; ?></td>
                                            <td><?php echo $alumno['email'] ?: 'Sin correo'; ?></td>
                                            <td>
                                                <?php if(empty($alumno['email'])) { ?>
                                                    <span class="badge bg-danger">Sin correo</span>
                                                <?php } else if(!empty($alumno['fecha_envio'])) { ?>
                                                    <span class="badge bg-success">Enviado el <?php echo date('d/m/Y', strtotime($alumno['fecha_envio'])); ?></span>
                                                <?php } else { ?>
                                                    <span class="badge bg-secondary">Pendiente</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-end mt-3">
                            <button type="button" class="btn btn-primary" id="enviarBoletas" disabled>
                                <i class="fas fa-paper-plane me-2"></i>
                                Enviar Boletas Seleccionadas
                            </button>
                        </div>
                    <?php } else if($id_grupo) { ?>
                        <div class="alert alert-info">
                            No hay alumnos registrados en este grupo.
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Cambio de grado
    $('#selectGrado').change(function() {
        const gradoId = $(this).val();
        window.location.href = 'enviar_boletas.php?grado=' + gradoId;
    });

    // Cambio de grupo
    $('#selectGrupo').change(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $(this).val();
        window.location.href = 'enviar_boletas.php?grado=' + gradoId + '&grupo=' + grupoId;
    });

    // Cambio de periodo
    $('#selectPeriodo').change(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $('#selectGrupo').val();
        const periodo = $(this).val();
        if(grupoId) {
            window.location.href = 'enviar_boletas.php?grado=' + gradoId + 
                                 '&grupo=' + grupoId + '&periodo=' + periodo;
        }
    });

    // Seleccionar todos
    $('#selectAll').change(function() {
        $('.alumno-check:not(:disabled)').prop('checked', $(this).prop('checked'));
        actualizarBotonEnviar();
    });

    // Actualizar botón al seleccionar alumnos
    $(document).on('change', '.alumno-check', function() {
        actualizarBotonEnviar();
    });

    function actualizarBotonEnviar() {
        const haySeleccionados = $('.alumno-check:checked').length > 0;
        $('#enviarBoletas').prop('disabled', !haySeleccionados);
    }

    // Enviar boletas
    $('#enviarBoletas').click(function() {
        const alumnosSeleccionados = $('.alumno-check:checked').map(function() {
            return $(this).val();
        }).get();

        if(!alumnosSeleccionados.length) {
            Swal.fire({
                icon: 'warning',
                title: 'Atención',
                text: 'Seleccione al menos un alumno'
            });
            return;
        }

        const boletaFile = $('#boletaFile')[0].files[0];
        if (!boletaFile) {
            Swal.fire({
                icon: 'warning',
                title: 'Atención',
                text: 'Por favor, seleccione un archivo para enviar'
            });
            return;
        }

        const formData = new FormData();
        formData.append('archivo', boletaFile);
        formData.append('alumnos', JSON.stringify(alumnosSeleccionados));
        formData.append('periodo', $('#selectPeriodo').val());
        formData.append('mensaje', $('#mensajeCorreo').val());

        Swal.fire({
            title: 'Enviando boletas...',
            text: 'Por favor espere',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/enviar_boletas.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                try {
                    const result = JSON.parse(response);
                    if(result.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Éxito!',
                            text: result.message
                        }).then(() => {
                            // Recargar la página para actualizar los estados
                            window.location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: result.message,
                            footer: result.error_details || ''
                        });
                    }
                } catch (e) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error en la respuesta del servidor'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error en la comunicación con el servidor'
                });
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?> 