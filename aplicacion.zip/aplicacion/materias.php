<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener todos los grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);

// Obtener todas las materias con sus grados
$query_materias = "SELECT m.*, g.nombre as nombre_grado 
                  FROM materias m 
                  JOIN grados g ON m.id_grado = g.id_grado 
                  ORDER BY g.nombre, m.nombre";
$resultado_materias = mysqli_query($conexion, $query_materias);
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                    <h6>Materias</h6>
                    <div>
                        <button class="btn btn-success btn-sm me-2" data-bs-toggle="modal" data-bs-target="#importarExcelModal">
                            <i class="fas fa-file-excel"></i> Importar Excel
                        </button>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#nuevaMateriaModal">
                            <i class="fas fa-plus"></i> Nueva Materia
                        </button>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Materia</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Grado</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Descripción</th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($materia = mysqli_fetch_assoc($resultado_materias)) { ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-3 py-1">
                                                <div class="d-flex flex-column justify-content-center">
                                                    <h6 class="mb-0 text-sm"><?php echo $materia['nombre']; ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0"><?php echo $materia['nombre_grado']; ?></p>
                                        </td>
                                        <td>
                                            <p class="text-sm text-secondary mb-0"><?php echo $materia['descripcion']; ?></p>
                                        </td>
                                        <td class="align-middle text-center">
                                            <button class="btn btn-warning btn-sm" 
                                                    onclick="editarMateria(<?php echo $materia['id_materia']; ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm" 
                                                    onclick="eliminarMateria(<?php echo $materia['id_materia']; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nueva Materia -->
<div class="modal fade" id="nuevaMateriaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nueva Materia</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevaMateria">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la Materia</label>
                        <input type="text" class="form-control" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Grado</label>
                        <select class="form-select" name="id_grado" required>
                            <option value="">Seleccionar Grado</option>
                            <?php 
                            mysqli_data_seek($resultado_grados, 0);
                            while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                <option value="<?php echo $grado['id_grado']; ?>">
                                    <?php echo $grado['nombre']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Importar Excel -->
<div class="modal fade" id="importarExcelModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importar Materias desde Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formImportarExcel" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Archivo Excel</label>
                        <input type="file" class="form-control" name="archivo_excel" accept=".xlsx,.xls" required>
                    </div>

                    <div class="alert alert-info">
                        <h6 class="mb-2"><i class="fas fa-info-circle"></i> Formato del Excel:</h6>
                        <p class="mb-0 small">El archivo debe contener las siguientes columnas:</p>
                        <ul class="mb-0 small">
                            <li>Columna A: Nombre de la materia</li>
                            <li>Columna B: Grado (nombre exacto del grado)</li>
                            <li>Columna C: Descripción (opcional)</li>
                        </ul>
                        <a href="actions/templates/generar_plantilla_materias.php" class="btn btn-sm btn-outline-primary mt-2">
                            <i class="fas fa-download"></i> Descargar Plantilla
                        </a>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload"></i> Importar
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Materia -->
<div class="modal fade" id="editarMateriaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Materia</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarMateria">
                    <input type="hidden" name="id_materia" id="edit_id_materia">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la Materia</label>
                        <input type="text" class="form-control" name="nombre" id="edit_nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Grado</label>
                        <select class="form-select" name="id_grado" id="edit_id_grado" required>
                            <option value="">Seleccionar Grado</option>
                            <?php 
                            mysqli_data_seek($resultado_grados, 0);
                            while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                <option value="<?php echo $grado['id_grado']; ?>">
                                    <?php echo $grado['nombre']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" id="edit_descripcion" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Manejar formulario de nueva materia
    $('#formNuevaMateria').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/materias/crear_materia.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    $('#nuevaMateriaModal').modal('hide');
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });

    // Manejar importación de Excel
    $('#formImportarExcel').submit(function(e) {
        e.preventDefault();
        
        let formData = new FormData(this);
        
        Swal.fire({
            title: 'Importando materias',
            text: 'Por favor espere...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/materias/importar_excel.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                try {
                    let data = JSON.parse(response);
                    if(data.success) {
                        if(data.errores && data.errores.length > 0) {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Importación parcial',
                                html: `
                                    <div class="text-start">
                                        <p>Se importaron ${data.importados} materias correctamente.</p>
                                        <p>Se encontraron los siguientes errores:</p>
                                        <div class="alert alert-warning" style="max-height: 200px; overflow-y: auto; text-align: left;">
                                            ${data.errores.join('<br>')}
                                        </div>
                                    </div>
                                `,
                                confirmButtonText: 'Entendido'
                            }).then(() => {
                                if(data.importados > 0) {
                                    location.reload();
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: '¡Éxito!',
                                text: data.message,
                                showConfirmButton: false,
                                timer: 1500
                            }).then(function() {
                                location.reload();
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message
                        });
                    }
                } catch(e) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al procesar la respuesta del servidor'
                    });
                }
            }
        });
    });

    // Manejar formulario de edición
    $('#formEditarMateria').submit(function(e) {
        e.preventDefault();
        
        Swal.fire({
            title: 'Actualizando...',
            text: 'Por favor espere',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/materias/editar_materia.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                $('#editarMateriaModal').modal('hide');
                
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });
});

function editarMateria(id_materia) {
    // Obtener datos de la materia
    $.ajax({
        url: 'actions/materias/obtener_materia.php',
        method: 'GET',
        data: { id: id_materia },
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                // Llenar el formulario con los datos
                $('#edit_id_materia').val(response.materia.id_materia);
                $('#edit_nombre').val(response.materia.nombre);
                $('#edit_id_grado').val(response.materia.id_grado);
                $('#edit_descripcion').val(response.materia.descripcion);
                
                // Mostrar el modal
                $('#editarMateriaModal').modal('show');
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message
                });
            }
        }
    });
}

function eliminarMateria(id_materia) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción no se puede deshacer",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('actions/materias/eliminar_materia.php', {id: id_materia}, function(response) {
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Eliminado!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }, 'json');
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?> 