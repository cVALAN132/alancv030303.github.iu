<?php
include 'includes/header.php';
require_once 'config/conexion.php';

if (!isset($_GET['id'])) {
    header('Location: grados_grupos.php');
    exit;
}

$id_grupo = mysqli_real_escape_string($conexion, $_GET['id']);

// Obtener información del grupo
$query_grupo = "SELECT g.*, gr.nombre as nombre_grado 
                FROM grupos g
                JOIN grados gr ON g.id_grado = gr.id_grado
                WHERE g.id_grupo = ?";
$stmt = mysqli_prepare($conexion, $query_grupo);
mysqli_stmt_bind_param($stmt, "i", $id_grupo);
mysqli_stmt_execute($stmt);
$resultado_grupo = mysqli_stmt_get_result($stmt);
$grupo = mysqli_fetch_assoc($resultado_grupo);

// Obtener alumnos del grupo
$query_alumnos = "SELECT a.*, 
                  (SELECT COUNT(*) FROM calificaciones c WHERE c.id_alumno = a.id_alumno) as total_calificaciones
                  FROM alumnos a
                  WHERE a.id_grupo = ?
                  ORDER BY a.nombre";
$stmt = mysqli_prepare($conexion, $query_alumnos);
mysqli_stmt_bind_param($stmt, "i", $id_grupo);
mysqli_stmt_execute($stmt);
$resultado_alumnos = mysqli_stmt_get_result($stmt);

// Obtener materias asignadas al grado
$query_materias = "SELECT * FROM materias WHERE id_grado = ? ORDER BY nombre";
$stmt = mysqli_prepare($conexion, $query_materias);
mysqli_stmt_bind_param($stmt, "i", $grupo['id_grado']);
mysqli_stmt_execute($stmt);
$resultado_materias = mysqli_stmt_get_result($stmt);
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0"><?php echo $grupo['nombre_grado'] . ' - Grupo ' . $grupo['nombre']; ?></h6>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="grados_grupos.php">Grados y Grupos</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Grupo <?php echo $grupo['nombre']; ?></li>
                            </ol>
                        </nav>
                    </div>
                    <div>
                        <button class="btn btn-success btn-sm me-2" data-bs-toggle="modal" data-bs-target="#importarExcelModal">
                            <i class="fas fa-file-excel"></i> Importar Excel
                        </button>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#nuevoAlumnoModal">
                            <i class="fas fa-user-plus"></i> Nuevo Alumno
                        </button>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Alumno</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Email</th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Calificaciones</th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($alumno = mysqli_fetch_assoc($resultado_alumnos)) { ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-3 py-1">
                                                <div class="d-flex flex-column justify-content-center">
                                                    <h6 class="mb-0 text-sm"><?php echo $alumno['nombre']; ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0"><?php echo $alumno['email']; ?></p>
                                        </td>
                                        <td class="align-middle text-center text-sm">
                                            <span class="badge badge-sm bg-gradient-success">
                                                <?php echo $alumno['total_calificaciones']; ?> calificaciones
                                            </span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <button class="btn btn-warning btn-sm" 
                                                    onclick="editarAlumno(<?php echo $alumno['id_alumno']; ?>, '<?php echo htmlspecialchars($alumno['nombre']); ?>', '<?php echo htmlspecialchars($alumno['email']); ?>')">
                                                <i class="fas fa-edit"></i> Editar
                                            </button>
                                            <button class="btn btn-danger btn-sm" 
                                                    onclick="eliminarAlumno(<?php echo $alumno['id_alumno']; ?>)">
                                                <i class="fas fa-trash"></i> Eliminar
                                            </button>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nuevo Alumno -->
<div class="modal fade" id="nuevoAlumnoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nuevo Alumno</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevoAlumno">
                    <input type="hidden" name="id_grupo" value="<?php echo $id_grupo; ?>">
                    <div class="mb-3">
                        <label class="form-label">Nombre Completo</label>
                        <input type="text" class="form-control" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Calificaciones -->
<div class="modal fade" id="calificacionesModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Calificaciones del Alumno</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="calificacionesContent"></div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Importar Excel -->
<div class="modal fade" id="importarExcelModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importar Alumnos desde Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formImportarExcel" enctype="multipart/form-data">
                    <input type="hidden" name="id_grupo" value="<?php echo $id_grupo; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Archivo Excel</label>
                        <input type="file" class="form-control" name="archivo_excel" accept=".xlsx,.xls" required>
                    </div>

                    <div class="alert alert-info">
                        <h6 class="mb-2"><i class="fas fa-info-circle"></i> Formato del Excel:</h6>
                        <p class="mb-0 small">El archivo debe contener las siguientes columnas:</p>
                        <ul class="mb-0 small">
                            <li>Columna A: Nombre del alumno</li>
                            <li>Columna B: Email del alumno</li>
                        </ul>
                        <a href="actions/templates/generar_plantilla_excel.php" class="btn btn-sm btn-outline-primary mt-2">
                            <i class="fas fa-download"></i> Descargar Plantilla
                        </a>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload"></i> Importar
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Agregar Modal de Edición -->
<div class="modal fade" id="editarAlumnoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Alumno</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarAlumno">
                    <input type="hidden" name="id_alumno" id="edit_id_alumno">
                    <input type="hidden" name="id_grupo" value="<?php echo $id_grupo; ?>">
                    <div class="mb-3">
                        <label class="form-label">Nombre Completo</label>
                        <input type="text" class="form-control" name="nombre" id="edit_nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="edit_email" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Manejar formulario de nuevo alumno
    $('#formNuevoAlumno').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/alumnos/crear_alumno.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    Swal.fire({ 
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });

    // Manejar importación de Excel
    $('#formImportarExcel').submit(function(e) {
        e.preventDefault();
        
        let formData = new FormData(this);
        
        // Mostrar loading
        Swal.fire({
            title: 'Importando alumnos',
            text: 'Por favor espere...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/alumnos/importar_excel.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                try {
                    let data = JSON.parse(response);
                    if(data.success) {
                        let mensaje = data.message;
                        
                        // Si hay errores, mostrar un modal con la lista detallada
                        if(data.errores && data.errores.length > 0) {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Importación parcial',
                                html: `
                                    <div class="text-start">
                                        <p>Se importaron ${data.importados} alumnos correctamente.</p>
                                        <p>Se encontraron los siguientes errores:</p>
                                        <div class="alert alert-warning" style="max-height: 200px; overflow-y: auto; text-align: left;">
                                            ${data.errores.join('<br>')}
                                        </div>
                                    </div>
                                `,
                                confirmButtonText: 'Entendido'
                            }).then(() => {
                                if(data.importados > 0) {
                                    location.reload();
                                }
                            });
                        } else {
                            // Si no hay errores, mostrar mensaje de éxito
                            Swal.fire({
                                icon: 'success',
                                title: '¡Éxito!',
                                text: mensaje,
                                showConfirmButton: false,
                                timer: 1500
                            }).then(function() {
                                location.reload();
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message
                        });
                    }
                } catch(e) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al procesar la respuesta del servidor'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error al comunicarse con el servidor'
                });
            }
        });
    });

    // Manejar formulario de edición
    $('#formEditarAlumno').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/alumnos/editar_alumno.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    Swal.fire({ 
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });
});

function verCalificaciones(id_alumno) {
    $.ajax({
        url: 'actions/calificaciones/obtener_calificaciones.php',
        type: 'GET',
        data: { id_alumno: id_alumno },
        success: function(response) {
            try {
                const data = JSON.parse(response);
                if (data.success) {
                    let html = `
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Materia</th>
                                    <th class="text-center">Calificación</th>
                                    <th class="text-center">Fecha</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;

                    if (data.calificaciones.length > 0) {
                        data.calificaciones.forEach(cal => {
                            // Determinar el color de la calificación
                            let badgeClass = cal.calificacion >= 6 ? 'bg-success' : 'bg-danger';
                            
                            html += `
                                <tr>
                                    <td>${cal.materia}</td>
                                    <td class="text-center">
                                        <span class="badge ${badgeClass}">
                                            ${cal.calificacion.toFixed(1)}
                                        </span>
                                    </td>
                                    <td class="text-center">${cal.fecha}</td>
                                </tr>
                            `;
                        });

                        // Calcular y mostrar promedio
                        const promedio = data.calificaciones.reduce((sum, cal) => sum + parseFloat(cal.calificacion), 0) / data.calificaciones.length;
                        html += `
                            <tr class="table-light">
                                <td><strong>Promedio General</strong></td>
                                <td colspan="2" class="text-center">
                                    <span class="badge bg-primary">${promedio.toFixed(2)}</span>
                                </td>
                            </tr>
                        `;
                    } else {
                        html += `
                            <tr>
                                <td colspan="3" class="text-center">
                                    No hay calificaciones registradas
                                </td>
                            </tr>
                        `;
                    }

                    html += `
                            </tbody>
                        </table>
                    </div>
                    `;

                    $('#calificacionesContent').html(html);
                    $('#calificacionesModal').modal('show');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Error al obtener calificaciones'
                    });
                }
            } catch (e) {
                console.error('Error al procesar la respuesta:', e);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error al procesar los datos'
                });
            }
        },
        error: function(xhr, status, error) {
            console.error('Error en la petición:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error al comunicarse con el servidor'
            });
        }
    });
}

function editarAlumno(id_alumno, nombre, email) {
    $('#edit_id_alumno').val(id_alumno);
    $('#edit_nombre').val(nombre);
    $('#edit_email').val(email);
    $('#editarAlumnoModal').modal('show');
}

function eliminarAlumno(id_alumno) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción no se puede revertir",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'actions/alumnos/eliminar_alumno.php',
                method: 'POST',
                data: { id_alumno: id_alumno },
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Eliminado!',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(function() {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message
                        });
                    }
                }
            });
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?> 