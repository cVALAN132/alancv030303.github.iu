<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener lista de grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);

// Obtener grupos si se seleccionó un grado
$id_grado = isset($_GET['grado']) ? $_GET['grado'] : null;
$grupos = [];
if($id_grado) {
    $query_grupos = "SELECT * FROM grupos WHERE id_grado = ? ORDER BY nombre";
    $stmt = mysqli_prepare($conexion, $query_grupos);
    mysqli_stmt_bind_param($stmt, "i", $id_grado);
    mysqli_stmt_execute($stmt);
    $resultado_grupos = mysqli_stmt_get_result($stmt);
}

// Obtener alumnos si se seleccionó un grupo
$id_grupo = isset($_GET['grupo']) ? $_GET['grupo'] : null;
$alumnos = [];
if($id_grupo) {
    $query_alumnos = "SELECT * FROM alumnos WHERE id_grupo = ? ORDER BY nombre";
    $stmt = mysqli_prepare($conexion, $query_alumnos);
    mysqli_stmt_bind_param($stmt, "i", $id_grupo);
    mysqli_stmt_execute($stmt);
    $resultado_alumnos = mysqli_stmt_get_result($stmt);
}

// Obtener materias del grado seleccionado
$materias = [];
if($id_grado) {
    $query_materias = "SELECT * FROM materias WHERE id_grado = ? ORDER BY nombre";
    $stmt = mysqli_prepare($conexion, $query_materias);
    mysqli_stmt_bind_param($stmt, "i", $id_grado);
    mysqli_stmt_execute($stmt);
    $resultado_materias = mysqli_stmt_get_result($stmt);
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                    <h6>Calificaciones</h6>
                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#nuevaCalificacionModal">
                        <i class="fas fa-plus"></i> Nueva Calificación
                    </button>
                </div>
                <div class="card-body">
                    <!-- Filtros -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="form-label">Grado</label>
                            <select class="form-select" id="selectGrado">
                                <option value="">Seleccionar Grado</option>
                                <?php while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                    <option value="<?php echo $grado['id_grado']; ?>" 
                                            <?php echo ($id_grado == $grado['id_grado']) ? 'selected' : ''; ?>>
                                        <?php echo $grado['nombre']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Grupo</label>
                            <select class="form-select" id="selectGrupo" <?php echo !$id_grado ? 'disabled' : ''; ?>>
                                <option value="">Seleccionar Grupo</option>
                                <?php if($id_grado && isset($resultado_grupos)) {
                                    while($grupo = mysqli_fetch_assoc($resultado_grupos)) { ?>
                                        <option value="<?php echo $grupo['id_grupo']; ?>"
                                                <?php echo ($id_grupo == $grupo['id_grupo']) ? 'selected' : ''; ?>>
                                            <?php echo $grupo['nombre']; ?>
                                        </option>
                                <?php }
                                } ?>
                            </select>
                        </div>
                    </div>

                    <!-- Tabla de Calificaciones -->
                    <?php if($id_grupo) { ?>
                        <div class="table-responsive">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th rowspan="2">Alumno</th>
                                        <?php 
                                        mysqli_data_seek($resultado_materias, 0);
                                        while($materia = mysqli_fetch_assoc($resultado_materias)) { ?>
                                            <th colspan="3" class="text-center"><?php echo $materia['nombre']; ?></th>
                                        <?php } ?>
                                        <th rowspan="2">Promedio General</th>
                                    </tr>
                                    <tr>
                                        <?php 
                                        mysqli_data_seek($resultado_materias, 0);
                                        while($materia = mysqli_fetch_assoc($resultado_materias)) { ?>
                                            <th class="text-center">P1</th>
                                            <th class="text-center">P2</th>
                                            <th class="text-center">P3</th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($alumno = mysqli_fetch_assoc($resultado_alumnos)) { ?>
                                        <tr>
                                            <td><?php echo $alumno['nombre']; ?></td>
                                            <?php 
                                            $suma_calificaciones = 0;
                                            $total_materias = 0;
                                            mysqli_data_seek($resultado_materias, 0);
                                            while($materia = mysqli_fetch_assoc($resultado_materias)) {
                                                // Consulta para obtener las calificaciones de los tres parciales
                                                $query_cal = "SELECT parcial, calificacion 
                                                            FROM calificaciones 
                                                            WHERE id_alumno = ? AND id_materia = ?
                                                            ORDER BY parcial";
                                                $stmt = mysqli_prepare($conexion, $query_cal);
                                                mysqli_stmt_bind_param($stmt, "ii", $alumno['id_alumno'], $materia['id_materia']);
                                                mysqli_stmt_execute($stmt);
                                                $resultado_cal = mysqli_stmt_get_result($stmt);
                                                
                                                // Inicializar array de calificaciones
                                                $calificaciones = ['-', '-', '-'];
                                                $suma_materia = 0;
                                                $parciales_con_cal = 0;
                                                
                                                // Llenar array con calificaciones existentes
                                                while($cal = mysqli_fetch_assoc($resultado_cal)) {
                                                    $calificaciones[$cal['parcial'] - 1] = $cal['calificacion'];
                                                    $suma_materia += $cal['calificacion'];
                                                    $parciales_con_cal++;
                                                }
                                                
                                                // Mostrar calificaciones de cada parcial
                                                foreach($calificaciones as $index => $cal) {
                                                    $parcial = $index + 1;
                                                    echo "<td class='text-center position-relative calificacion-cell'>";
                                                    if($cal != '-') {
                                                        echo "<span class='calificacion-valor'>" . $cal . "</span>";
                                                        echo "<div class='calificacion-acciones'>";
                                                        echo "<button class='btn btn-link btn-sm text-warning p-0 me-2' onclick='editarCalificacion(" . 
                                                             $alumno['id_alumno'] . ", " . $materia['id_materia'] . ", " . $parcial . ", " . $cal . 
                                                             ")'><i class='fas fa-edit'></i></button>";
                                                        echo "<button class='btn btn-link btn-sm text-danger p-0' onclick='eliminarCalificacion(" . 
                                                             $alumno['id_alumno'] . ", " . $materia['id_materia'] . ", " . $parcial . 
                                                             ")'><i class='fas fa-trash'></i></button>";
                                                        echo "</div>";
                                                    } else {
                                                        echo $cal;
                                                    }
                                                    echo "</td>";
                                                }
                                                
                                                // Calcular promedio de la materia si hay calificaciones
                                                if($parciales_con_cal > 0) {
                                                    $suma_calificaciones += ($suma_materia / $parciales_con_cal);
                                                    $total_materias++;
                                                }
                                            } ?>
                                            <td class="text-center fw-bold">
                                                <?php 
                                                echo $total_materias > 0 ? 
                                                    number_format($suma_calificaciones / $total_materias, 1) : '-'; 
                                                ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        <div class="text-center py-4">
                            <p>Selecciona un grado y grupo para ver las calificaciones</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Actualizar el Modal Nueva Calificación -->
<div class="modal fade" id="nuevaCalificacionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nueva Calificación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevaCalificacion">
                    <div class="mb-3">
                        <label class="form-label">Parcial</label>
                        <select class="form-select" name="parcial" required>
                            <option value="1">Primer Parcial</option>
                            <option value="2">Segundo Parcial</option>
                            <option value="3">Tercer Parcial</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alumno</label>
                        <select class="form-select" name="id_alumno" required>
                            <option value="">Seleccionar Alumno</option>
                            <?php 
                            if($id_grupo) {
                                mysqli_data_seek($resultado_alumnos, 0);
                                while($alumno = mysqli_fetch_assoc($resultado_alumnos)) { ?>
                                    <option value="<?php echo $alumno['id_alumno']; ?>">
                                        <?php echo $alumno['nombre']; ?>
                                    </option>
                                <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Materia</label>
                        <select class="form-select" name="id_materia" required>
                            <option value="">Seleccionar Materia</option>
                            <?php 
                            if($id_grado) {
                                mysqli_data_seek($resultado_materias, 0);
                                while($materia = mysqli_fetch_assoc($resultado_materias)) { ?>
                                    <option value="<?php echo $materia['id_materia']; ?>">
                                        <?php echo $materia['nombre']; ?>
                                    </option>
                                <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Calificación</label>
                        <input type="number" class="form-control" name="calificacion" 
                               min="0" max="10" step="0.1" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Calificación -->
<div class="modal fade" id="editarCalificacionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Calificación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarCalificacion">
                    <input type="hidden" name="id_alumno" id="edit_id_alumno">
                    <input type="hidden" name="id_materia" id="edit_id_materia">
                    <input type="hidden" name="parcial" id="edit_parcial">
                    <div class="mb-3">
                        <label class="form-label">Calificación</label>
                        <input type="number" class="form-control" name="calificacion" id="edit_calificacion"
                               min="0" max="10" step="0.1" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Mover las funciones fuera del document.ready
function editarCalificacion(id_alumno, id_materia, parcial, calificacion) {
    $('#edit_id_alumno').val(id_alumno);
    $('#edit_id_materia').val(id_materia);
    $('#edit_parcial').val(parcial);
    $('#edit_calificacion').val(calificacion);
    $('#editarCalificacionModal').modal('show');
}

function eliminarCalificacion(id_alumno, id_materia, parcial) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción no se puede revertir",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'actions/calificaciones/eliminar_calificacion.php',
                method: 'POST',
                data: {
                    id_alumno: id_alumno,
                    id_materia: id_materia,
                    parcial: parcial
                },
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Eliminado!',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message
                        });
                    }
                }
            });
        }
    });
}

$(document).ready(function() {
    // Manejar cambio de grado
    $('#selectGrado').change(function() {
        const gradoId = $(this).val();
        window.location.href = 'calificaciones.php?grado=' + gradoId;
    });

    // Manejar cambio de grupo
    $('#selectGrupo').change(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $(this).val();
        window.location.href = 'calificaciones.php?grado=' + gradoId + '&grupo=' + grupoId;
    });

    // Actualizar el manejador del formulario de nueva calificación
    $('#formNuevaCalificacion').submit(function(e) {
        e.preventDefault();
        
        // Mostrar indicador de carga
        Swal.fire({
            title: 'Guardando...',
            text: 'Por favor espere',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/calificaciones/guardar_calificacion.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                console.log('Respuesta:', response); // Para debug
                
                $('#nuevaCalificacionModal').modal('hide');
                
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message || 'Calificación guardada correctamente',
                        showConfirmButton: true
                    }).then((result) => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message || 'Error al guardar la calificación'
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error); // Para debug
                $('#nuevaCalificacionModal').modal('hide');
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Hubo un error al procesar la solicitud'
                });
            }
        });
    });

    // Asegurarse de que el formulario de edición esté correctamente vinculado
    $('#formEditarCalificacion').on('submit', function(e) {
        e.preventDefault();
        
        Swal.fire({
            title: 'Actualizando...',
            text: 'Por favor espere',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/calificaciones/editar_calificacion.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                $('#editarCalificacionModal').modal('hide');
                
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>

