<?php
// Configuración del correo
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'alancollado111@gmail.com');
define('SMTP_PASSWORD', 'joxuvfojeligvelm');
define('SMTP_PORT', 465);
define('SMTP_FROM_EMAIL', 'alancollado111@gmail.com');
define('SMTP_FROM_NAME', 'Sistema de Calificaciones');
?> 
