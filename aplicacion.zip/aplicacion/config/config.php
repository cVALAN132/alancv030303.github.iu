<?php
// Definir la URL base del proyecto
define('BASE_URL', 'http://localhost/aplicacion/'); // Ajusta esto según tu configuración
?> 