<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener estadísticas generales
$query_total_alumnos = "SELECT COUNT(*) as total FROM alumnos";
$query_total_materias = "SELECT COUNT(*) as total FROM materias";
$query_total_grupos = "SELECT COUNT(*) as total FROM grupos";
$query_promedio_general = "SELECT AVG(calificacion) as promedio FROM calificaciones";

$total_alumnos = mysqli_fetch_assoc(mysqli_query($conexion, $query_total_alumnos))['total'];
$total_materias = mysqli_fetch_assoc(mysqli_query($conexion, $query_total_materias))['total'];
$total_grupos = mysqli_fetch_assoc(mysqli_query($conexion, $query_total_grupos))['total'];
$promedio_general = number_format(mysqli_fetch_assoc(mysqli_query($conexion, $query_promedio_general))['promedio'], 2);

// Obtener últimas calificaciones registradas
$query_ultimas_calificaciones = "
    SELECT c.calificacion, a.nombre as alumno, m.nombre as materia, 
           DATE_FORMAT(c.fecha_registro, '%d/%m/%Y') as fecha
    FROM calificaciones c
    JOIN alumnos a ON c.id_alumno = a.id_alumno
    JOIN materias m ON c.id_materia = m.id_materia
    ORDER BY c.fecha_registro DESC
    LIMIT 5";
$resultado_calificaciones = mysqli_query($conexion, $query_ultimas_calificaciones);

// Obtener promedios por materia
$query_promedios_materia = "
    SELECT m.nombre, ROUND(IFNULL(AVG(c.calificacion), 0), 2) as promedio
    FROM materias m 
    LEFT JOIN calificaciones c ON m.id_materia = c.id_materia 
    GROUP BY m.id_materia, m.nombre 
    ORDER BY promedio DESC 
    LIMIT 5";
$resultado_promedios = mysqli_query($conexion, $query_promedios_materia);

// Verifica si la consulta fue exitosa
if (!$resultado_promedios) {
    echo "Error en la consulta: " . mysqli_error($conexion);
}

// Obtener alumnos destacados
$query_alumnos_destacados = "
    SELECT a.nombre, AVG(c.calificacion) as promedio
    FROM calificaciones c
    JOIN alumnos a ON c.id_alumno = a.id_alumno
    GROUP BY a.id_alumno
    HAVING promedio >= 9
    ORDER BY promedio DESC
    LIMIT 5";
$resultado_destacados = mysqli_query($conexion, $query_alumnos_destacados);
?>

<div class="container-fluid py-4">
    <!-- Tarjetas de Estadísticas -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-sm-6">
            <div class="card stat-card bg-gradient-primary text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                        <div class="ms-3">
                            <h3 class="mb-1"><?php echo $total_alumnos; ?></h3>
                            <p class="mb-0">Alumnos</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6">
            <div class="card stat-card bg-gradient-success text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box">
                            <i class="fas fa-book fa-2x"></i>
                        </div>
                        <div class="ms-3">
                            <h3 class="mb-1"><?php echo $total_materias; ?></h3>
                            <p class="mb-0">Materias</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6">
            <div class="card stat-card bg-gradient-info text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box">
                            <i class="fas fa-school fa-2x"></i>
                        </div>
                        <div class="ms-3">
                            <h3 class="mb-1"><?php echo $total_grupos; ?></h3>
                            <p class="mb-0">Grupos</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6">
            <div class="card stat-card bg-gradient-warning text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box">
                            <i class="fas fa-star fa-2x"></i>
                        </div>
                        <div class="ms-3">
                            <h3 class="mb-1"><?php echo $promedio_general; ?></h3>
                            <p class="mb-0">Promedio General</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficas y Tablas -->
    <div class="row g-4">
        <!-- Gráfica de Promedios por Materia -->
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Promedios por Materia</h5>
                </div>
                <div class="card-body">
                    <canvas id="promediosChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>

        <!-- Alumnos Destacados -->
        <div class="col-xl-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Alumnos Destacados</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Alumno</th>
                                    <th>Promedio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($alumno = mysqli_fetch_assoc($resultado_destacados)): ?>
                                <tr>
                                    <td><?php echo $alumno['nombre']; ?></td>
                                    <td>
                                        <span class="badge bg-success">
                                            <?php echo number_format($alumno['promedio'], 2); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Últimas Calificaciones -->
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Últimas Calificaciones Registradas</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Alumno</th>
                                    <th>Materia</th>
                                    <th>Calificación</th>
                                    <th>Fecha</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($cal = mysqli_fetch_assoc($resultado_calificaciones)): ?>
                                <tr>
                                    <td><?php echo $cal['alumno']; ?></td>
                                    <td><?php echo $cal['materia']; ?></td>
                                    <td>
                                        <span class="badge <?php echo $cal['calificacion'] >= 6 ? 'bg-success' : 'bg-danger'; ?>">
                                            <?php echo $cal['calificacion']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $cal['fecha']; ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.stat-card {
    border: none;
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.bg-gradient-primary {
    background: linear-gradient(45deg, #4e73df, #224abe);
}

.bg-gradient-success {
    background: linear-gradient(45deg, #1cc88a, #13855c);
}

.bg-gradient-info {
    background: linear-gradient(45deg, #36b9cc, #258391);
}

.bg-gradient-warning {
    background: linear-gradient(45deg, #f6c23e, #dda20a);
}

.icon-box {
    width: 64px;
    height: 64px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.2);
}

.table > :not(caption) > * > * {
    padding: 1rem;
}

.chart-container {
    position: relative;
    height: 300px;
    width: 100%;
}

#promediosChart {
    width: 100% !important;
    height: 100% !important;
}

.card {
    height: 100%;
}
.card-body {
    position: relative;
}
canvas {
    width: 100% !important;
    height: 100% !important;
}
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>
<script>
window.onload = function() {
    // Datos de PHP
    var materias = [];
    var promedios = [];
    
    <?php
    if ($resultado_promedios) {
        while ($row = mysqli_fetch_array($resultado_promedios)) {
            echo "materias.push('" . $row['nombre'] . "');\n";
            echo "promedios.push(" . $row['promedio'] . ");\n";
        }
    }
    ?>

    // Configuración de la gráfica
    var ctx = document.getElementById('promediosChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: materias,
            datasets: [{
                label: 'Promedio',
                data: promedios,
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        max: 10
                    }
                }]
            }
        }
    });
};
</script>

<?php include 'includes/footer.php'; ?>
