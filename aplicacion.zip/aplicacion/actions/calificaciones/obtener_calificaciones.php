<?php
require_once '../../config/conexion.php';

if (isset($_GET['id_alumno'])) {
    try {
        $id_alumno = mysqli_real_escape_string($conexion, $_GET['id_alumno']);
        
        // Consulta para obtener calificaciones con manejo seguro de fechas
        $query = "SELECT 
                    c.id_calificacion,
                    c.calificacion,
                    m.nombre as materia,
                    IFNULL(DATE_FORMAT(c.fecha_registro, '%d/%m/%Y'), DATE_FORMAT(NOW(), '%d/%m/%Y')) as fecha
                 FROM calificaciones c
                 INNER JOIN materias m ON c.id_materia = m.id_materia
                 WHERE c.id_alumno = ?
                 ORDER BY c.fecha_registro DESC";

        $stmt = mysqli_prepare($conexion, $query);
        
        if (!$stmt) {
            throw new Exception("Error en la preparación de la consulta: " . mysqli_error($conexion));
        }

        mysqli_stmt_bind_param($stmt, "i", $id_alumno);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Error al ejecutar la consulta: " . mysqli_stmt_error($stmt));
        }

        $resultado = mysqli_stmt_get_result($stmt);
        
        if (!$resultado) {
            throw new Exception("Error al obtener resultados: " . mysqli_error($conexion));
        }

        $calificaciones = [];
        
        while ($row = mysqli_fetch_assoc($resultado)) {
            $calificaciones[] = [
                'id_calificacion' => $row['id_calificacion'],
                'materia' => $row['materia'],
                'calificacion' => floatval($row['calificacion']),
                'fecha' => $row['fecha']
            ];
        }

        echo json_encode([
            'success' => true,
            'calificaciones' => $calificaciones
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'error_details' => mysqli_error($conexion)
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No se proporcionó el ID del alumno'
    ]);
}

mysqli_close($conexion);
?> 