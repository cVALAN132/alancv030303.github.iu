<?php
require_once '../../config/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $parcial = $_POST['parcial'];
        $id_alumno = $_POST['id_alumno'];
        $id_materia = $_POST['id_materia'];
        $calificacion = $_POST['calificacion'];

        // Verificar si ya existe una calificación para este alumno, materia y parcial
        $query_check = "SELECT id_calificacion FROM calificaciones 
                       WHERE id_alumno = ? AND id_materia = ? AND parcial = ?";
        $stmt = mysqli_prepare($conexion, $query_check);
        mysqli_stmt_bind_param($stmt, "iii", $id_alumno, $id_materia, $parcial);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($resultado) > 0) {
            // Actualizar calificación existente
            $query = "UPDATE calificaciones SET calificacion = ? 
                     WHERE id_alumno = ? AND id_materia = ? AND parcial = ?";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "diii", $calificacion, $id_alumno, $id_materia, $parcial);
        } else {
            // Insertar nueva calificación
            $query = "INSERT INTO calificaciones (id_alumno, id_materia, parcial, calificacion) 
                     VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "iiid", $id_alumno, $id_materia, $parcial, $calificacion);
        }

        if (mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Calificación guardada correctamente'
            ]);
        } else {
            throw new Exception("Error al guardar la calificación");
        }

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
?> 