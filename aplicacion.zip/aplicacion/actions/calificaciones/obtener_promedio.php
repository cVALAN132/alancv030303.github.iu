<?php
require_once '../../config/conexion.php';

if (isset($_GET['id_alumno'])) {
    try {
        $id_alumno = mysqli_real_escape_string($conexion, $_GET['id_alumno']);
        
        $query = "SELECT AVG(calificacion) as promedio 
                 FROM calificaciones 
                 WHERE id_alumno = ?";
        
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "i", $id_alumno);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        $promedio = mysqli_fetch_assoc($resultado);
        
        // Verificar si hay promedio y formatearlo
        $promedio_final = isset($promedio['promedio']) ? $promedio['promedio'] : 0;
        
        echo json_encode([
            'success' => true,
            'promedio' => number_format(floatval($promedio_final), 2)
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 