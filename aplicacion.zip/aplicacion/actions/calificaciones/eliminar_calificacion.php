<?php
require_once '../../config/conexion.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_alumno = $_POST['id_alumno'];
    $id_materia = $_POST['id_materia'];
    $parcial = $_POST['parcial'];

    $query = "DELETE FROM calificaciones 
              WHERE id_alumno = ? AND id_materia = ? AND parcial = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "iii", $id_alumno, $id_materia, $parcial);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Calificación eliminada correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al eliminar la calificación'
        ]);
    }
} 