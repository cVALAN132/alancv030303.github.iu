<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/conexion.php';
require_once '../config/mail_config.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $alumnos = json_decode($_POST['alumnos']);
    $periodo = $_POST['periodo'];
    $mensaje = $_POST['mensaje'];
    $enviados = 0;
    $errores = 0;
    $error_detalles = '';

    // Verificar archivo
    if (!isset($_FILES['archivo'])) {
        die(json_encode([
            'success' => false,
            'message' => 'No se recibió ningún archivo'
        ]));
    }

    $archivo = $_FILES['archivo'];
    $archivo_nombre = $archivo['name'];
    $archivo_temporal = $archivo['tmp_name'];

    foreach($alumnos as $id_alumno) {
        $query = "SELECT a.nombre, a.email as correo 
                 FROM alumnos a 
                 WHERE a.id_alumno = '$id_alumno'";
        $resultado = mysqli_query($conexion, $query);
        $alumno = mysqli_fetch_assoc($resultado);

        if (!$alumno || empty($alumno['correo'])) {
            $errores++;
            continue;
        }

        try {
            $mail = new PHPMailer(true);
            
            // Configuración de debug
            $mail->SMTPDebug = 2;  // Habilitar debug
            $mail->Debugoutput = 'error_log';  // Enviar debug al error_log
            
            // Configuración del servidor
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USERNAME;
            $mail->Password = SMTP_PASSWORD;
            $mail->SMTPSecure = 'ssl';  // Cambiado a 'ssl' explícitamente
            $mail->Port = 465;  // Puerto para SSL
            
            // Configuración adicional de seguridad
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            
            // Resto de la configuración
            $mail->CharSet = 'UTF-8';
            $mail->setFrom(SMTP_USERNAME, SMTP_FROM_NAME);
            $mail->addAddress($alumno['correo'], $alumno['nombre']);
            
            // Contenido
            $mail->isHTML(true);
            $mail->Subject = "Boleta de Calificaciones - Periodo {$periodo}";
            $mail->Body = nl2br($mensaje);
            $mail->AltBody = strip_tags($mensaje);
            
            // Adjuntar archivo
            $mail->addAttachment($archivo_temporal, $archivo_nombre);

            if(!$mail->send()) {
                $errores++;
                $error_detalles .= "Error al enviar a {$alumno['nombre']}: " . $mail->ErrorInfo . "\n";
            } else {
                $enviados++;
                // Registrar el envío exitoso
                $fecha_actual = date('Y-m-d H:i:s');
                $query_registro = "INSERT INTO boletas_enviadas (id_alumno, periodo, fecha_envio) 
                                  VALUES ('$id_alumno', '$periodo', '$fecha_actual')
                                  ON DUPLICATE KEY UPDATE fecha_envio = '$fecha_actual'";
                mysqli_query($conexion, $query_registro);
            }
            
        } catch (Exception $e) {
            $errores++;
            $error_detalles .= "Error con {$alumno['nombre']}: " . $e->getMessage() . "\n";
        }
    }

    echo json_encode([
        'success' => ($errores === 0),
        'message' => "Se encontraron errores al enviar las boletas. Enviados: {$enviados}, Errores: {$errores}",
        'error_details' => $error_detalles
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
?> 