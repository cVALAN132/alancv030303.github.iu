<?php
require_once '../config/conexion.php';
header('Content-Type: application/json');

if(isset($_POST['id'])) {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    
    $query = "DELETE FROM calificaciones WHERE id_calificacion = '$id'";
    
    if(mysqli_query($conexion, $query)) {
        echo json_encode([
            'success' => true,
            'message' => 'Calificación eliminada correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al eliminar: ' . mysqli_error($conexion)
        ]);
    }
}
?> 