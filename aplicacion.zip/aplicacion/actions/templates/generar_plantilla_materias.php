<?php
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Crear una nueva hoja de cálculo
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Establecer el título de la hoja
$sheet->setTitle('Plantilla Materias');

// Definir los encabezados
$headers = ['Nombre de la Materia', 'Grado', 'Descripción'];

// Estilo para los encabezados
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['rgb' => 'FFFFFF'],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '2563EB'],
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
];

// Aplicar encabezados y estilos
foreach (range('A', 'C') as $col) {
    $sheet->getColumnDimension($col)->setWidth(35);
}
$sheet->getRowDimension(1)->setRowHeight(30);

for ($i = 0; $i < count($headers); $i++) {
    $col = chr(65 + $i);
    $sheet->setCellValue($col . '1', $headers[$i]);
}

$sheet->getStyle('A1:C1')->applyFromArray($headerStyle);

// Obtener los grados disponibles de la base de datos
require_once '../../config/conexion.php';
$query_grados = "SELECT nombre FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);
$grados = [];
while ($row = mysqli_fetch_assoc($resultado_grados)) {
    $grados[] = $row['nombre'];
}

// Definir el grado por defecto
$gradoPorDefecto = isset($grados[0]) ? $grados[0] : 'Primer Grado';

// Agregar datos de ejemplo
$exampleData = [
    ['Matemáticas', $gradoPorDefecto, 'Fundamentos de aritmética y álgebra'],
    ['Español', $gradoPorDefecto, 'Comprensión lectora y escritura'],
    ['Ciencias', $gradoPorDefecto, 'Introducción a las ciencias naturales'],
];

$row = 2;
foreach ($exampleData as $data) {
    $sheet->setCellValue('A' . $row, $data[0]);
    $sheet->setCellValue('B' . $row, $data[1]);
    $sheet->setCellValue('C' . $row, $data[2]);
    $row++;
}

// Agregar validación para la columna de Grado
$validation = $sheet->getCell('B2')->getDataValidation();
$validation->setType(\PhpOffice\PhpSpreadsheet\Cell\DataValidation::TYPE_LIST);
$validation->setErrorStyle(\PhpOffice\PhpSpreadsheet\Cell\DataValidation::STYLE_INFORMATION);
$validation->setAllowBlank(false);
$validation->setShowInputMessage(true);
$validation->setShowErrorMessage(true);
$validation->setShowDropDown(true);
$validation->setErrorTitle('Error de entrada');
$validation->setError('El valor no está en la lista.');
$validation->setPromptTitle('Seleccione un grado');
$validation->setPrompt('Seleccione un grado de la lista.');
$validation->setFormula1('"' . implode(',', $grados) . '"');

// Copiar la validación a las demás celdas de la columna B
for ($i = 3; $i <= 50; $i++) {
    $sheet->getCell('B' . $i)->setDataValidation(clone $validation);
}

// Estilo para los datos de ejemplo
$dataStyle = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => 'CCCCCC'],
        ],
    ],
    'alignment' => [
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
];

$sheet->getStyle('A2:C' . ($row-1))->applyFromArray($dataStyle);

// Agregar nota informativa
$sheet->setCellValue('A' . ($row + 1), 'Notas:');
$sheet->mergeCells('A' . ($row + 1) . ':C' . ($row + 1));
$sheet->setCellValue('A' . ($row + 2), '- El nombre de la materia y el grado son obligatorios');
$sheet->mergeCells('A' . ($row + 2) . ':C' . ($row + 2));
$sheet->setCellValue('A' . ($row + 3), '- La descripción es opcional');
$sheet->mergeCells('A' . ($row + 3) . ':C' . ($row + 3));
$sheet->setCellValue('A' . ($row + 4), '- Seleccione el grado de la lista desplegable');
$sheet->mergeCells('A' . ($row + 4) . ':C' . ($row + 4));

// Estilo para las notas
$notasStyle = [
    'font' => [
        'italic' => true,
        'size' => 10,
        'color' => ['rgb' => '666666'],
    ],
];

$sheet->getStyle('A' . ($row + 1) . ':C' . ($row + 4))->applyFromArray($notasStyle);

// Proteger la hoja excepto las celdas para datos
$sheet->getProtection()->setSheet(true);
$sheet->getStyle('A2:C50')->getProtection()->setLocked(false);

// Crear el archivo
$writer = new Xlsx($spreadsheet);

// Configurar headers para la descarga
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="formato_materias.xlsx"');
header('Cache-Control: max-age=0');

// Guardar el archivo
$writer->save('php://output');
exit;
?> 