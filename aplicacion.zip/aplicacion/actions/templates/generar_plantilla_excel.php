<?php
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Crear una nueva hoja de cálculo
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Establecer el título de la hoja
$sheet->setTitle('Plantilla Alumnos');

// Definir los encabezados
$headers = ['Nombre del Alumno', 'Email'];

// Estilo para los encabezados
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['rgb' => 'FFFFFF'],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '2563EB'],
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
];

// Aplicar encabezados y estilos
foreach (range('A', 'B') as $col) {
    $sheet->getColumnDimension($col)->setWidth(30);
}
$sheet->getRowDimension(1)->setRowHeight(30);

for ($i = 0; $i < count($headers); $i++) {
    $col = chr(65 + $i);
    $sheet->setCellValue($col . '1', $headers[$i]);
}

$sheet->getStyle('A1:B1')->applyFromArray($headerStyle);

// Agregar datos de ejemplo
$exampleData = [
    ['Juan Pérez', 'juan.perez@ejemplo.com'],
    ['María García', 'maria.garcia@ejemplo.com'],
];

$row = 2;
foreach ($exampleData as $data) {
    $sheet->setCellValue('A' . $row, $data[0]);
    $sheet->setCellValue('B' . $row, $data[1]);
    $row++;
}

// Estilo para los datos de ejemplo
$dataStyle = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => 'CCCCCC'],
        ],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_LEFT,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
];

$sheet->getStyle('A2:B' . ($row-1))->applyFromArray($dataStyle);

// Proteger la hoja excepto las celdas para datos
$sheet->getProtection()->setSheet(true);
$sheet->getStyle('A2:B50')->getProtection()->setLocked(false);

// Crear el archivo
$writer = new Xlsx($spreadsheet);

// Configurar headers para la descarga
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="formato_alumnos.xlsx"');
header('Cache-Control: max-age=0');

// Guardar el archivo
$writer->save('php://output');
exit;
?> 