<?php
require_once '../../config/conexion.php';
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (!isset($_FILES['archivo_excel']) || $_FILES['archivo_excel']['error'] > 0) {
            throw new Exception('Error al subir el archivo');
        }

        $archivo = $_FILES['archivo_excel']['tmp_name'];
        
        // Cargar archivo Excel
        $spreadsheet = IOFactory::load($archivo);
        $worksheet = $spreadsheet->getActiveSheet();
        $highestRow = $worksheet->getHighestRow();

        // Iniciar transacción
        mysqli_begin_transaction($conexion);

        $materias_importadas = 0;
        $errores = [];

        // Obtener todos los grados para validación
        $query_grados = "SELECT id_grado, nombre FROM grados";
        $resultado_grados = mysqli_query($conexion, $query_grados);
        $grados = [];
        while($grado = mysqli_fetch_assoc($resultado_grados)) {
            $grados[strtolower($grado['nombre'])] = $grado['id_grado'];
        }

        // Empezar desde la fila 2 (después de los encabezados)
        for ($row = 2; $row <= $highestRow; $row++) {
            $nombre = trim($worksheet->getCellByColumnAndRow(1, $row)->getValue());
            $grado_nombre = trim($worksheet->getCellByColumnAndRow(2, $row)->getValue());
            $descripcion = trim($worksheet->getCellByColumnAndRow(3, $row)->getValue());

            // Saltar filas vacías
            if (empty($nombre) || empty($grado_nombre)) {
                continue;
            }

            // Validar que existe el grado
            $grado_key = strtolower($grado_nombre);
            if (!isset($grados[$grado_key])) {
                $errores[] = "Fila $row: El grado '$grado_nombre' no existe en el sistema";
                continue;
            }

            $id_grado = $grados[$grado_key];

            // Verificar si ya existe la materia en ese grado
            $query_check = "SELECT id_materia FROM materias WHERE nombre = ? AND id_grado = ?";
            $stmt = mysqli_prepare($conexion, $query_check);
            mysqli_stmt_bind_param($stmt, "si", $nombre, $id_grado);
            mysqli_stmt_execute($stmt);
            
            if(mysqli_stmt_get_result($stmt)->num_rows > 0) {
                $errores[] = "Fila $row: La materia '$nombre' ya existe en el grado '$grado_nombre'";
                continue;
            }

            // Insertar materia
            $query = "INSERT INTO materias (nombre, id_grado, descripcion) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "sis", $nombre, $id_grado, $descripcion);
            
            if(mysqli_stmt_execute($stmt)) {
                $materias_importadas++;
            } else {
                $errores[] = "Fila $row: Error al insertar la materia '$nombre'";
            }
        }

        // Si no se importó ninguna materia y hay errores
        if ($materias_importadas == 0 && !empty($errores)) {
            mysqli_rollback($conexion);
            throw new Exception("No se pudo importar ninguna materia.\n\nErrores encontrados:\n" . implode("\n", $errores));
        }

        // Confirmar transacción
        mysqli_commit($conexion);

        echo json_encode([
            'success' => true,
            'message' => "Se importaron $materias_importadas materias correctamente",
            'importados' => $materias_importadas,
            'errores' => $errores
        ]);

    } catch (Exception $e) {
        if (mysqli_connect_errno()) {
            mysqli_rollback($conexion);
        }
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 