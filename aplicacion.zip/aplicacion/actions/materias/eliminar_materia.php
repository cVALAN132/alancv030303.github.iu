<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if(!isset($_POST['id'])) {
            throw new Exception('ID de materia no proporcionado');
        }

        $id_materia = mysqli_real_escape_string($conexion, $_POST['id']);

        // Verificar si hay calificaciones asociadas
        $query_check = "SELECT COUNT(*) as total FROM calificaciones WHERE id_materia = ?";
        $stmt = mysqli_prepare($conexion, $query_check);
        mysqli_stmt_bind_param($stmt, "i", $id_materia);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if($resultado['total'] > 0) {
            throw new Exception('No se puede eliminar la materia porque tiene calificaciones asociadas');
        }

        // Eliminar materia
        $query = "DELETE FROM materias WHERE id_materia = ?";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "i", $id_materia);
        
        if(mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Materia eliminada correctamente'
            ]);
        } else {
            throw new Exception("Error al eliminar la materia");
        }

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 