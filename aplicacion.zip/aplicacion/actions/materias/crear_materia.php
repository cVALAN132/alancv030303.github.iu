<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Validar datos recibidos
        if(empty($_POST['nombre']) || empty($_POST['id_grado'])) {
            throw new Exception('El nombre y el grado son obligatorios');
        }

        $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
        $id_grado = mysqli_real_escape_string($conexion, $_POST['id_grado']);
        $descripcion = isset($_POST['descripcion']) ? mysqli_real_escape_string($conexion, $_POST['descripcion']) : '';

        // Verificar si ya existe una materia con el mismo nombre en el mismo grado
        $query_check = "SELECT id_materia FROM materias WHERE nombre = ? AND id_grado = ?";
        $stmt = mysqli_prepare($conexion, $query_check);
        mysqli_stmt_bind_param($stmt, "si", $nombre, $id_grado);
        mysqli_stmt_execute($stmt);
        
        if(mysqli_stmt_get_result($stmt)->num_rows > 0) {
            throw new Exception('Ya existe una materia con este nombre en el grado seleccionado');
        }

        // Insertar materia
        $query = "INSERT INTO materias (nombre, id_grado, descripcion) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "sis", $nombre, $id_grado, $descripcion);
        
        if(mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Materia creada correctamente'
            ]);
        } else {
            throw new Exception("Error al crear la materia");
        }

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 