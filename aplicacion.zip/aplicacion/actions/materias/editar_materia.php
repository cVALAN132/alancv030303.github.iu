<?php
require_once '../../config/conexion.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_materia = $_POST['id_materia'];
    $nombre = $_POST['nombre'];
    $id_grado = $_POST['id_grado'];
    $descripcion = $_POST['descripcion'];
    
    $query = "UPDATE materias SET nombre = ?, id_grado = ?, descripcion = ? 
              WHERE id_materia = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "sisi", $nombre, $id_grado, $descripcion, $id_materia);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Materia actualizada correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al actualizar la materia'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
} 