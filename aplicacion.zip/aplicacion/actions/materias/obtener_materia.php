<?php
require_once '../../config/conexion.php';
header('Content-Type: application/json');

if(isset($_GET['id'])) {
    $id_materia = $_GET['id'];
    
    $query = "SELECT * FROM materias WHERE id_materia = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_materia);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    
    if($materia = mysqli_fetch_assoc($resultado)) {
        echo json_encode([
            'success' => true,
            'materia' => $materia
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Materia no encontrada'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'ID no proporcionado'
    ]);
}
?> 