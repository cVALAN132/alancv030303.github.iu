<?php
require_once '../config/conexion.php';
header('Content-Type: application/json');

if(isset($_POST['id_alumno'])) {
    $id_alumno = mysqli_real_escape_string($conexion, $_POST['id_alumno']);
    
    $query = "SELECT m.nombre, c.calificacion 
              FROM calificaciones c 
              JOIN materias m ON c.id_materia = m.id_materia 
              WHERE c.id_alumno = '$id_alumno' 
              ORDER BY m.nombre";
    
    $resultado = mysqli_query($conexion, $query);
    
    $materias = array();
    $calificaciones = array();
    
    while($row = mysqli_fetch_assoc($resultado)) {
        $materias[] = $row['nombre'];
        $calificaciones[] = (float)$row['calificacion'];
    }
    
    $data = array(
        'labels' => $materias,
        'datasets' => array(
            array(
                'label' => 'Calificaciones',
                'data' => $calificaciones,
                'borderColor' => 'rgb(75, 192, 192)',
                'tension' => 0.1
            )
        )
    );
    
    echo json_encode($data);
}
?> 