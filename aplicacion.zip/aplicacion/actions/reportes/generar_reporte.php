<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    try {
        if(!isset($_GET['grado']) || !isset($_GET['grupo']) || !isset($_GET['tipo'])) {
            throw new Exception('Faltan parámetros requeridos');
        }

        $id_grado = mysqli_real_escape_string($conexion, $_GET['grado']);
        $id_grupo = mysqli_real_escape_string($conexion, $_GET['grupo']);
        $tipo = mysqli_real_escape_string($conexion, $_GET['tipo']);

        // Validar tipo de reporte
        $tipos_validos = ['general', 'promedios', 'reprobados'];
        if (!in_array($tipo, $tipos_validos)) {
            throw new Exception('Tipo de reporte no válido');
        }

        // Obtener información del grupo y grado
        $query_info = "SELECT g.nombre as grupo, gr.nombre as grado
                      FROM grupos g 
                      JOIN grados gr ON g.id_grado = gr.id_grado
                      WHERE g.id_grupo = ? AND gr.id_grado = ?";
        $stmt = mysqli_prepare($conexion, $query_info);
        mysqli_stmt_bind_param($stmt, "ii", $id_grupo, $id_grado);
        mysqli_stmt_execute($stmt);
        $resultado_info = mysqli_stmt_get_result($stmt);
        $info = mysqli_fetch_assoc($resultado_info);

        if (!$info) {
            throw new Exception('No se encontró el grupo especificado');
        }

        // Obtener materias del grado
        $query_materias = "SELECT * FROM materias WHERE id_grado = ? ORDER BY nombre";
        $stmt = mysqli_prepare($conexion, $query_materias);
        mysqli_stmt_bind_param($stmt, "i", $id_grado);
        mysqli_stmt_execute($stmt);
        $resultado_materias = mysqli_stmt_get_result($stmt);
        $materias = [];
        while($materia = mysqli_fetch_assoc($resultado_materias)) {
            $materias[] = $materia;
        }

        // Obtener alumnos y sus calificaciones
        $query_alumnos = "SELECT * FROM alumnos WHERE id_grupo = ? ORDER BY nombre";
        $stmt = mysqli_prepare($conexion, $query_alumnos);
        mysqli_stmt_bind_param($stmt, "i", $id_grupo);
        mysqli_stmt_execute($stmt);
        $resultado_alumnos = mysqli_stmt_get_result($stmt);

        $datos = [];
        while($alumno = mysqli_fetch_assoc($resultado_alumnos)) {
            $calificaciones = [];
            $suma = 0;
            $count = 0;

            foreach($materias as $materia) {
                $query_cal = "SELECT calificacion FROM calificaciones 
                             WHERE id_alumno = ? AND id_materia = ?";
                $stmt = mysqli_prepare($conexion, $query_cal);
                mysqli_stmt_bind_param($stmt, "ii", $alumno['id_alumno'], $materia['id_materia']);
                mysqli_stmt_execute($stmt);
                $cal = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

                if($cal) {
                    $calificaciones[$materia['id_materia']] = floatval($cal['calificacion']);
                    $suma += floatval($cal['calificacion']);
                    $count++;
                } else {
                    $calificaciones[$materia['id_materia']] = 0;
                }
            }

            $promedio = $count > 0 ? $suma / $count : 0;

            // Filtrar según el tipo de reporte
            $incluir = true;
            if($tipo == 'reprobados' && $promedio >= 6) {
                $incluir = false;
            }

            if($incluir) {
                $datos[] = [
                    'alumno' => $alumno,
                    'calificaciones' => $calificaciones,
                    'promedio' => $promedio
                ];
            }
        }

        // Verificar que tenemos todos los datos necesarios
        if (!isset($info) || !isset($materias) || !isset($datos)) {
            throw new Exception('Error al obtener los datos del reporte');
        }

        // Generar HTML del reporte
        ob_start();
        $template_path = '../../templates/reportes/' . $tipo . '.php';
        
        if (!file_exists($template_path)) {
            throw new Exception('Plantilla no encontrada: ' . $tipo);
        }

        // Incluir la plantilla con las variables disponibles
        include $template_path;
        $html = ob_get_clean();

        if (empty($html)) {
            throw new Exception('Error al generar el reporte');
        }

        echo json_encode([
            'success' => true,
            'html' => $html,
            'debug' => [
                'info' => $info,
                'materias_count' => count($materias),
                'alumnos_count' => count($datos)
            ]
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?>
