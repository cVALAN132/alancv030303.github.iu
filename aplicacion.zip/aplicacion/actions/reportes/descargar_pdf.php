<?php
require_once '../../config/conexion.php';
require '../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    try {
        if(!isset($_GET['grado']) || !isset($_GET['grupo']) || !isset($_GET['tipo'])) {
            throw new Exception('Faltan parámetros requeridos');
        }

        $id_grado = mysqli_real_escape_string($conexion, $_GET['grado']);
        $id_grupo = mysqli_real_escape_string($conexion, $_GET['grupo']);
        $tipo = mysqli_real_escape_string($conexion, $_GET['tipo']);

        // Validar tipo de reporte
        $tipos_validos = ['general', 'promedios', 'reprobados'];
        if (!in_array($tipo, $tipos_validos)) {
            throw new Exception('Tipo de reporte no válido');
        }

        // Obtener información del grupo y grado
        $query_info = "SELECT g.nombre as grupo, gr.nombre as grado
                      FROM grupos g 
                      JOIN grados gr ON g.id_grado = gr.id_grado
                      WHERE g.id_grupo = ? AND gr.id_grado = ?";
        $stmt = mysqli_prepare($conexion, $query_info);
        mysqli_stmt_bind_param($stmt, "ii", $id_grupo, $id_grado);
        mysqli_stmt_execute($stmt);
        $resultado_info = mysqli_stmt_get_result($stmt);
        $info = mysqli_fetch_assoc($resultado_info);

        if (!$info) {
            throw new Exception('No se encontró el grupo especificado');
        }

        // Obtener materias del grado
        $query_materias = "SELECT * FROM materias WHERE id_grado = ? ORDER BY nombre";
        $stmt = mysqli_prepare($conexion, $query_materias);
        mysqli_stmt_bind_param($stmt, "i", $id_grado);
        mysqli_stmt_execute($stmt);
        $resultado_materias = mysqli_stmt_get_result($stmt);
        $materias = [];
        while($materia = mysqli_fetch_assoc($resultado_materias)) {
            $materias[] = $materia;
        }

        // Obtener alumnos y sus calificaciones
        $query_alumnos = "SELECT * FROM alumnos WHERE id_grupo = ? ORDER BY nombre";
        $stmt = mysqli_prepare($conexion, $query_alumnos);
        mysqli_stmt_bind_param($stmt, "i", $id_grupo);
        mysqli_stmt_execute($stmt);
        $resultado_alumnos = mysqli_stmt_get_result($stmt);

        $datos = [];
        while($alumno = mysqli_fetch_assoc($resultado_alumnos)) {
            $calificaciones = [];
            $suma = 0;
            $count = 0;

            foreach($materias as $materia) {
                $query_cal = "SELECT calificacion FROM calificaciones 
                             WHERE id_alumno = ? AND id_materia = ?";
                $stmt = mysqli_prepare($conexion, $query_cal);
                mysqli_stmt_bind_param($stmt, "ii", $alumno['id_alumno'], $materia['id_materia']);
                mysqli_stmt_execute($stmt);
                $cal = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

                if($cal) {
                    $calificaciones[$materia['id_materia']] = floatval($cal['calificacion']);
                    $suma += floatval($cal['calificacion']);
                    $count++;
                } else {
                    $calificaciones[$materia['id_materia']] = 0;
                }
            }

            $promedio = $count > 0 ? $suma / $count : 0;

            // Filtrar según el tipo de reporte
            $incluir = true;
            if($tipo == 'reprobados' && $promedio >= 6) {
                $incluir = false;
            }

            if($incluir) {
                $datos[] = [
                    'alumno' => $alumno,
                    'calificaciones' => $calificaciones,
                    'promedio' => $promedio
                ];
            }
        }

        // Configurar DOMPDF
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);
        $options->set('defaultFont', 'Arial');

        $dompdf = new Dompdf($options);

        // Agregar estilos CSS para el PDF
        $html = '
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { background-color: #004080; color: white; padding: 10px; text-align: center; }
            .header h2, .header h3 { margin: 0; }
            .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            .table th { background-color: #f2f2f2; }
            .table tr:nth-child(even) { background-color: #f9f9f9; }
            .table tr:hover { background-color: #ddd; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
        <div class="header">
            <h2>SISTEMA DE GESTION ACADEMICA</h2>
            <h3>BOLETA DE CALIFICACIONES</h3>
        </div>
        ';

        // Obtener contenido de la plantilla
        ob_start();
        include '../../templates/reportes/' . $tipo . '.php';
        $html .= ob_get_clean();

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        // Generar nombre del archivo
        $filename = 'Reporte_' . $info['grado'] . '_Grupo_' . $info['grupo'] . '_' . date('Y-m-d') . '.pdf';
        
        // Descargar PDF
        $dompdf->stream($filename, [
            "Attachment" => true
        ]);

    } catch (Exception $e) {
        echo 'Error al generar el PDF: ' . $e->getMessage();
    }
}
?> 