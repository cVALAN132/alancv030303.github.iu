<?php
require_once '../config/conexion.php';

if(isset($_POST['id'])) {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    
    $query = "SELECT * FROM alumnos WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    
    if($alumno = mysqli_fetch_assoc($resultado)) {
        echo json_encode($alumno);
    } else {
        echo json_encode(['error' => 'Alumno no encontrado']);
    }
}
?> 