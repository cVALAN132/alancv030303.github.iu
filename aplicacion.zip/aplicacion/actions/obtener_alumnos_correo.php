<?php
require_once '../config/conexion.php';

if(isset($_POST['grado']) && isset($_POST['grupo'])) {
    $grado = mysqli_real_escape_string($conexion, $_POST['grado']);
    $grupo = mysqli_real_escape_string($conexion, $_POST['grupo']);
    
    $query = "SELECT a.id_alumno, a.nombre, a.correo 
              FROM alumnos a 
              INNER JOIN grados_grupos gg ON a.id_grado_grupo = gg.id_grado_grupo 
              WHERE gg.grado = ? AND gg.grupo = ?
              ORDER BY a.nombre";
              
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ss", $grado, $grupo);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    
    if(mysqli_num_rows($resultado) > 0) {
        while($alumno = mysqli_fetch_assoc($resultado)) {
            echo "<tr>
                    <td>
                        <input type='checkbox' class='form-check-input alumno-check' 
                               value='".$alumno['id_alumno']."'>
                    </td>
                    <td>".$alumno['nombre']."</td>
                    <td>".$alumno['correo']."</td>
                    <td><span class='badge bg-secondary'>Pendiente</span></td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='4' class='text-center'>No se encontraron alumnos</td></tr>";
    }
    
    mysqli_stmt_close($stmt);
}
?> 