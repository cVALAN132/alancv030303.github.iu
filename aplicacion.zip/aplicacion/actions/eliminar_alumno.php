<?php
require_once '../config/conexion.php';

if(isset($_POST['id'])) {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    
    // Primero verificar si hay calificaciones asociadas
    $check_query = "SELECT id_calificacion FROM calificaciones WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $check_query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if(mysqli_num_rows($result) > 0) {
        echo json_encode(['status' => 'error', 'message' => 'No se puede eliminar el alumno porque tiene calificaciones registradas']);
        exit;
    }
    
    // Si no hay calificaciones, proceder con la eliminación
    $query = "DELETE FROM alumnos WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al eliminar el alumno']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'ID no proporcionado']);
}
?> 