<?php
require_once '../config/conexion.php';

if(isset($_POST['id_alumno'])) {
    $id = mysqli_real_escape_string($conexion, $_POST['id_alumno']);
    $matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    
    $query = "UPDATE alumnos SET matricula = ?, nombre = ?, email = ? WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $matricula, $nombre, $email, $id);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al actualizar']);
    }
}
?> 