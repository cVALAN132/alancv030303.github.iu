<?php
require_once '../../config/conexion.php';
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (!isset($_FILES['archivo_excel']) || $_FILES['archivo_excel']['error'] > 0) {
            throw new Exception('Error al subir el archivo');
        }

        $id_grupo = mysqli_real_escape_string($conexion, $_POST['id_grupo']);
        $archivo = $_FILES['archivo_excel']['tmp_name'];
        
        // Cargar archivo Excel
        $spreadsheet = IOFactory::load($archivo);
        $worksheet = $spreadsheet->getActiveSheet();
        $highestRow = $worksheet->getHighestRow();

        // Iniciar transacción
        mysqli_begin_transaction($conexion);

        $alumnos_importados = 0;
        $errores = [];

        // Función para sanitizar y validar email
        function sanitizeEmail($email) {
            // Eliminar espacios
            $email = trim($email);
            
            // Convertir a minúsculas
            $email = strtolower($email);
            
            // Sanitizar caracteres especiales
            $email = str_replace(['á','é','í','ó','ú','ñ'], ['a','e','i','o','u','n'], $email);
            
            // Validar formato básico de email
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return $email;
            }
            return false;
        }

        // Empezar desde la fila 2 (después de los encabezados)
        for ($row = 2; $row <= $highestRow; $row++) {
            $nombre = trim($worksheet->getCellByColumnAndRow(1, $row)->getValue());
            $email_original = trim($worksheet->getCellByColumnAndRow(2, $row)->getValue());

            // Saltar filas vacías
            if (empty($nombre) || empty($email_original)) {
                continue;
            }

            // Sanitizar y validar email
            $email = sanitizeEmail($email_original);
            
            if (!$email) {
                $errores[] = "Fila $row: El email '$email_original' no tiene un formato válido. Por favor, verifica que no contenga caracteres especiales.";
                continue;
            }

            // Verificar si el email ya existe
            $query_check = "SELECT id_alumno FROM alumnos WHERE email = ?";
            $stmt = mysqli_prepare($conexion, $query_check);
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            
            if(mysqli_stmt_get_result($stmt)->num_rows > 0) {
                $errores[] = "Fila $row: El email '$email' ya está registrado en el sistema.";
                continue;
            }

            // Insertar alumno
            $query = "INSERT INTO alumnos (nombre, email, id_grupo) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "ssi", $nombre, $email, $id_grupo);
            
            if(mysqli_stmt_execute($stmt)) {
                $alumnos_importados++;
            } else {
                $errores[] = "Fila $row: Error al insertar el alumno '$nombre'";
            }
        }

        // Si no se importó ningún alumno y hay errores
        if ($alumnos_importados == 0 && !empty($errores)) {
            mysqli_rollback($conexion);
            throw new Exception("No se pudo importar ningún alumno.\n\nErrores encontrados:\n" . implode("\n", $errores));
        }

        // Confirmar transacción
        mysqli_commit($conexion);

        $mensaje = "Se importaron $alumnos_importados alumnos correctamente.";
        if (!empty($errores)) {
            $mensaje .= "\n\nAdvertencias:\n" . implode("\n", $errores);
        }

        echo json_encode([
            'success' => true,
            'message' => $mensaje,
            'importados' => $alumnos_importados,
            'errores' => $errores
        ]);

    } catch (Exception $e) {
        if (mysqli_connect_errno()) {
            mysqli_rollback($conexion);
        }
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 