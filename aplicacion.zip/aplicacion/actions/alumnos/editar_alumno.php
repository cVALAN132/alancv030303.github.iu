<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_alumno = $_POST['id_alumno'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    
    $query = "UPDATE alumnos SET nombre = ?, email = ? WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $nombre, $email, $id_alumno);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Alumno actualizado correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el alumno']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
} 