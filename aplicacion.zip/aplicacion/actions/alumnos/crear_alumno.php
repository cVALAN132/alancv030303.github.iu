<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
        $email = mysqli_real_escape_string($conexion, $_POST['email']);
        $id_grupo = mysqli_real_escape_string($conexion, $_POST['id_grupo']);
        
        $query = "INSERT INTO alumnos (nombre, email, id_grupo) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "ssi", $nombre, $email, $id_grupo);
        
        if(mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Alumno agregado correctamente'
            ]);
        } else {
            throw new Exception("Error al agregar el alumno");
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 