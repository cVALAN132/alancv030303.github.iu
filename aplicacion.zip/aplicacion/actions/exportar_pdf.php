<?php
require_once '../config/conexion.php';
require_once '../vendor/setasign/fpdf/fpdf.php';

class PDF extends FPDF {
    function Header() {
        // Arial bold 15
        $this->SetFont('Arial','B',16);
        // Título
        $this->Cell(0,10,utf8_decode('Reporte de Calificaciones'),0,1,'C');
        // Salto de línea
        $this->Ln(10);
        
        // Cabeceras de la tabla
        $this->SetFont('Arial','B',12);
        $this->SetFillColor(40,55,71);
        $this->SetTextColor(255,255,255);
        $this->Cell(70,10,'Alumno',1,0,'C',true);
        $this->Cell(50,10,'Materia',1,0,'C',true);
        $this->Cell(35,10,utf8_decode('Calificación'),1,0,'C',true);
        $this->Cell(35,10,'Fecha',1,1,'C',true);
        
        // Restaurar color de texto
        $this->SetTextColor(0,0,0);
    }
    
    function Footer() {
        // Posición: a 1,5 cm del final
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial','I',8);
        // Número de página
        $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
    }
}

// Crear nuevo PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',11);

// Obtener datos
$query = "SELECT a.nombre as alumno, m.nombre as materia, c.calificacion, c.fecha_registro 
          FROM calificaciones c 
          JOIN alumnos a ON c.id_alumno = a.id_alumno 
          JOIN materias m ON c.id_materia = m.id_materia 
          ORDER BY a.nombre ASC";
$resultado = mysqli_query($conexion, $query);

// Colores alternados para las filas
$fill = false;

while($row = mysqli_fetch_assoc($resultado)) {
    $pdf->SetFillColor(245,246,250);
    $pdf->Cell(70,10,utf8_decode($row['alumno']),1,0,'L',$fill);
    $pdf->Cell(50,10,utf8_decode($row['materia']),1,0,'L',$fill);
    $pdf->Cell(35,10,$row['calificacion'],1,0,'C',$fill);
    $pdf->Cell(35,10,date('d/m/Y', strtotime($row['fecha_registro'])),1,1,'C',$fill);
    $fill = !$fill;
}

$pdf->Output('D', 'calificaciones.pdf');
?> 