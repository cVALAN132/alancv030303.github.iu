<?php
session_start();
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_usuario = $_POST['id_usuario'];
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $usuario = mysqli_real_escape_string($conexion, $_POST['usuario']);
    $password = $_POST['password'];
    
    // Verificar si el usuario ya existe
    $check_query = "SELECT id_usuario FROM usuarios WHERE usuario = ? AND id_usuario != ?";
    $stmt = mysqli_prepare($conexion, $check_query);
    mysqli_stmt_bind_param($stmt, "si", $usuario, $id_usuario);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if(mysqli_num_rows($result) > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'El nombre de usuario ya está en uso'
        ]);
        exit;
    }
    
    // Preparar la consulta base
    if($password) {
        $password_hash = md5($password);
        $query = "UPDATE usuarios SET nombre = ?, usuario = ?, password = ? WHERE id_usuario = ?";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "sssi", $nombre, $usuario, $password_hash, $id_usuario);
    } else {
        $query = "UPDATE usuarios SET nombre = ?, usuario = ? WHERE id_usuario = ?";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "ssi", $nombre, $usuario, $id_usuario);
    }
    
    if(mysqli_stmt_execute($stmt)) {
        // Actualizar datos de sesión
        $_SESSION['nombre'] = $nombre;
        $_SESSION['usuario'] = $usuario;
        
        echo json_encode([
            'success' => true,
            'message' => 'Perfil actualizado correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al actualizar el perfil'
        ]);
    }
    
    mysqli_stmt_close($stmt);
}
?> 