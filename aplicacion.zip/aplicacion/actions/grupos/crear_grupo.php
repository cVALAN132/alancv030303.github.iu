<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $id_grado = mysqli_real_escape_string($conexion, $_POST['id_grado']);
        $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
        
        $query = "INSERT INTO grupos (id_grado, nombre) VALUES (?, ?)";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "is", $id_grado, $nombre);
        
        if(mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Grupo creado correctamente'
            ]);
        } else {
            throw new Exception("Error al crear el grupo");
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 