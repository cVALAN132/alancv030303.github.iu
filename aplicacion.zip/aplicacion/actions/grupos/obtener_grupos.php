<?php
require_once '../../config/conexion.php';

if (isset($_GET['id_grado'])) {
    try {
        $id_grado = mysqli_real_escape_string($conexion, $_GET['id_grado']);
        
        $query = "SELECT * FROM grupos WHERE id_grado = ? ORDER BY nombre";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "i", $id_grado);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        
        $grupos = [];
        while ($grupo = mysqli_fetch_assoc($resultado)) {
            $grupos[] = $grupo;
        }
        
        echo json_encode([
            'success' => true,
            'grupos' => $grupos
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 