<?php
require_once '../../config/conexion.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_grupo = $_POST['id_grupo'];
    $nombre = $_POST['nombre'];
    $id_grado = $_POST['id_grado'];
    
    $query = "UPDATE grupos SET nombre = ?, id_grado = ? WHERE id_grupo = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "sii", $nombre, $id_grado, $id_grupo);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Grupo actualizado correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al actualizar el grupo'
        ]);
    }
} 