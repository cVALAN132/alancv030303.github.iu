<?php
require_once '../config/conexion.php';
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if(isset($_FILES['archivo'])) {
    try {
        $archivo = $_FILES['archivo']['tmp_name'];
        $spreadsheet = IOFactory::load($archivo);
        $worksheet = $spreadsheet->getActiveSheet();
        $rows = $worksheet->toArray();
        
        // Eliminar la primera fila (encabezados)
        array_shift($rows);
        
        $importados = 0;
        $errores = 0;
        
        foreach($rows as $row) {
            if(!empty($row[0]) && !empty($row[1])) { // Verificar datos mínimos
                $matricula = mysqli_real_escape_string($conexion, trim($row[0]));
                $nombre = mysqli_real_escape_string($conexion, trim($row[1]));
                
                // Manejo seguro del email
                $email = isset($row[2]) ? mysqli_real_escape_string($conexion, trim($row[2])) : '';
                
                // Verificar si la matrícula ya existe
                $check = mysqli_query($conexion, "SELECT id_alumno FROM alumnos WHERE matricula = '$matricula'");
                if(mysqli_num_rows($check) == 0) {
                    $query = "INSERT INTO alumnos (matricula, nombre, email) VALUES (?, ?, ?)";
                    $stmt = mysqli_prepare($conexion, $query);
                    mysqli_stmt_bind_param($stmt, "sss", $matricula, $nombre, $email);
                    
                    if(mysqli_stmt_execute($stmt)) {
                        $importados++;
                    } else {
                        $errores++;
                    }
                } else {
                    $errores++;
                }
            }
        }
        
        echo json_encode([
            'status' => 'success',
            'message' => "Se importaron $importados alumnos exitosamente. Errores: $errores"
        ]);
        
    } catch(Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Error al procesar el archivo: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'No se recibió ningún archivo'
    ]);
} 