<?php
require_once '../config/conexion.php';

// Headers para Excel
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename=calificaciones.xls');
header('Pragma: no-cache');
header('Expires: 0');

// Consulta
$query = "SELECT a.nombre as alumno, m.nombre as materia, c.calificacion, c.fecha_registro 
          FROM calificaciones c 
          JOIN alumnos a ON c.id_alumno = a.id_alumno 
          JOIN materias m ON c.id_materia = m.id_materia 
          ORDER BY a.nombre ASC";
$resultado = mysqli_query($conexion, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        .header {
            background-color: #283747;
            color: white;
            font-weight: bold;
        }
        .row-data:nth-child(even) {
            background-color: #F5F6FA;
        }
    </style>
</head>
<body>
    <h2>Reporte de Calificaciones</h2>
    <table border="1">
        <thead>
            <tr class="header">
                <th style="width:250px; background-color: #283747; color: white;">Alumno</th>
                <th style="width:200px; background-color: #283747; color: white;">Materia</th>
                <th style="width:100px; background-color: #283747; color: white;">Calificación</th>
                <th style="width:100px; background-color: #283747; color: white;">Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_assoc($resultado)): ?>
            <tr class="row-data">
                <td><?php echo utf8_decode($row['alumno']); ?></td>
                <td><?php echo utf8_decode($row['materia']); ?></td>
                <td style="text-align: center;"><?php echo $row['calificacion']; ?></td>
                <td style="text-align: center;"><?php echo date('d/m/Y', strtotime($row['fecha_registro'])); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html> 