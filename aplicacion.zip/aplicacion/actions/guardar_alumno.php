<?php
require_once '../config/conexion.php';
require_once '../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    
    // Validar que los campos no estén vacíos
    if(empty($matricula) || empty($nombre) || empty($email)) {
        echo json_encode([
            'success' => false, 
            'message' => 'Todos los campos son obligatorios'
        ]);
        exit;
    }
    
    // Verificar si la matrícula ya existe
    $check = mysqli_query($conexion, "SELECT id_alumno FROM alumnos WHERE matricula = '$matricula'");
    if(mysqli_num_rows($check) > 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'La matrícula ya existe'
        ]);
        exit;
    }
    
    $query = "INSERT INTO alumnos (matricula, nombre, email) VALUES ('$matricula', '$nombre', '$email')";
    
    if(mysqli_query($conexion, $query)) {
        echo json_encode([
            'success' => true,
            'message' => 'Alumno guardado correctamente',
            'redirect' => BASE_URL . 'alumnos.php'
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Error al guardar: ' . mysqli_error($conexion)
        ]);
    }
}
?> 