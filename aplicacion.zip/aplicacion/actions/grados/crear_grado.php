<?php
require_once '../../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
        
        $query = "INSERT INTO grados (nombre) VALUES (?)";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "s", $nombre);
        
        if(mysqli_stmt_execute($stmt)) {
            echo json_encode([
                'success' => true,
                'message' => 'Grado creado correctamente'
            ]);
        } else {
            throw new Exception("Error al crear el grado");
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
?> 