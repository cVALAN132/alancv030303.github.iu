<?php
require_once '../../config/conexion.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_grado = $_POST['id_grado'];
    $nombre = $_POST['nombre'];
    
    $query = "UPDATE grados SET nombre = ? WHERE id_grado = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "si", $nombre, $id_grado);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Grado actualizado correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al actualizar el grado'
        ]);
    }
} 