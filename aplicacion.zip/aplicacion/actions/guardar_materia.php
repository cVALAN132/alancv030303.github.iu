<?php
require_once '../config/conexion.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validar que los campos no estén vacíos
    if(empty($_POST['nombre']) || empty($_POST['creditos'])) {
        echo json_encode([
            'success' => false,
            'message' => 'El nombre y los créditos son obligatorios'
        ]);
        exit;
    }

    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $descripcion = mysqli_real_escape_string($conexion, $_POST['descripcion']);
    $creditos = mysqli_real_escape_string($conexion, $_POST['creditos']);
    
    // Verificar si la materia ya existe
    $check = mysqli_query($conexion, "SELECT id_materia FROM materias WHERE nombre = '$nombre'");
    if(mysqli_num_rows($check) > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Esta materia ya existe'
        ]);
        exit;
    }
    
    $query = "INSERT INTO materias (nombre, descripcion, creditos) 
              VALUES ('$nombre', '$descripcion', '$creditos')";
    
    if(mysqli_query($conexion, $query)) {
        echo json_encode([
            'success' => true,
            'message' => 'Materia guardada correctamente'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error al guardar: ' . mysqli_error($conexion)
        ]);
    }
}
?> 