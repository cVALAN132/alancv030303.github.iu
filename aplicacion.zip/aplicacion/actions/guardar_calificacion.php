<?php
require_once '../config/conexion.php';

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_alumno = $_POST['id_alumno'];
    $id_materia = $_POST['id_materia'];
    $calificacion = $_POST['calificacion'];
    $parcial = $_POST['parcial'];

    // Verificar si ya existe una calificación para este alumno, materia y parcial
    $query_check = "SELECT id FROM calificaciones 
                   WHERE id_alumno = ? AND id_materia = ? AND parcial = ?";
    $stmt = mysqli_prepare($conexion, $query_check);
    mysqli_stmt_bind_param($stmt, "iii", $id_alumno, $id_materia, $parcial);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($resultado) > 0) {
        // Actualizar calificación existente
        $query = "UPDATE calificaciones 
                 SET calificacion = ? 
                 WHERE id_alumno = ? AND id_materia = ? AND parcial = ?";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "diii", $calificacion, $id_alumno, $id_materia, $parcial);
    } else {
        // Insertar nueva calificación
        $query = "INSERT INTO calificaciones (id_alumno, id_materia, calificacion, parcial) 
                 VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "iidi", $id_alumno, $id_materia, $calificacion, $parcial);
    }

    if (mysqli_stmt_execute($stmt)) {
        $response['success'] = true;
        $response['message'] = 'Calificación guardada correctamente';
    } else {
        $response['message'] = 'Error al guardar la calificación';
    }
} else {
    $response['message'] = 'Método no permitido';
}

echo json_encode($response);
?> 