<?php
require_once '../config/conexion.php';

$where = "1=1";
if(isset($_POST['alumno']) && $_POST['alumno'] != '') {
    $alumno = mysqli_real_escape_string($conexion, $_POST['alumno']);
    $where .= " AND c.id_alumno = '$alumno'";
}
if(isset($_POST['materia']) && $_POST['materia'] != '') {
    $materia = mysqli_real_escape_string($conexion, $_POST['materia']);
    $where .= " AND c.id_materia = '$materia'";
}

$query = "SELECT c.*, a.nombre as nombre_alumno, m.nombre as nombre_materia 
          FROM calificaciones c 
          JOIN alumnos a ON c.id_alumno = a.id_alumno 
          JOIN materias m ON c.id_materia = m.id_materia 
          WHERE $where 
          ORDER BY c.fecha_registro DESC";

$resultado = mysqli_query($conexion, $query);

while($row = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>{$row['nombre_alumno']}</td>";
    echo "<td>{$row['nombre_materia']}</td>";
    echo "<td>{$row['calificacion']}</td>";
    echo "<td>" . date('d/m/Y', strtotime($row['fecha_registro'])) . "</td>";
    echo "<td>";
    echo "<button type='button' class='btn btn-sm btn-info me-2 ver-rendimiento' data-id='{$row['id_alumno']}'>";
    echo "<i class='fas fa-chart-line'></i>";
    echo "</button>";
    echo "<button class='btn btn-sm btn-danger eliminar-calificacion' data-id='{$row['id_calificacion']}'>";
    echo "<i class='fas fa-trash'></i>";
    echo "</button>";
    echo "</td>";
    echo "</tr>";
}
?> 