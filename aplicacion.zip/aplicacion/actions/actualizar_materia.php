<?php
require_once '../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_materia = mysqli_real_escape_string($conexion, $_POST['id_materia']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $descripcion = mysqli_real_escape_string($conexion, $_POST['descripcion']);
    $creditos = mysqli_real_escape_string($conexion, $_POST['creditos']);

    $query = "UPDATE materias SET 
              nombre = ?, 
              descripcion = ?, 
              creditos = ? 
              WHERE id_materia = ?";
              
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ssii", $nombre, $descripcion, $creditos, $id_materia);
    
    if(mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Materia actualizada correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar la materia']);
    }
}
?> 