<?php
require_once 'config/conexion.php';
require_once 'vendor/fpdf/fpdf/src/Fpdf/Fpdf.php';

use Fpdf\Fpdf;

class PDF extends FPDF {
    function Header() {
        // Fondo del encabezado
        $this->SetFillColor(0, 48, 135);
        $this->Rect(0, 0, 220, 40, 'F');
        
        // Título
        $this->SetFont('Arial', 'B', 20);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 15, 'SISTEMA DE GESTION ACADEMICA', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'BOLETA DE CALIFICACIONES', 0, 1, 'C');
        
        // Restaurar colores
        $this->SetTextColor(0, 0, 0);
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-30);
        $this->SetDrawColor(0, 48, 135);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Documento oficial - Sistema de Gestión Académica', 0, 1, 'C');
        $this->Cell(0, 5, 'Página ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

// Obtener parámetros
$id_grado = isset($_GET['grado']) ? $_GET['grado'] : null;
$id_grupo = isset($_GET['grupo']) ? $_GET['grupo'] : null;
$parcial = isset($_GET['parcial']) ? $_GET['parcial'] : 1;
$id_alumno = isset($_GET['alumno']) ? $_GET['alumno'] : null;

if(!$id_grado || !$id_grupo || !$parcial) {
    die('Parámetros incompletos');
}

// Crear nuevo PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Obtener información del alumno
$query = "SELECT a.*, g.nombre as nombre_grado, gr.nombre as nombre_grupo 
          FROM alumnos a 
          JOIN grupos gr ON a.id_grupo = gr.id_grupo 
          JOIN grados g ON gr.id_grado = g.id_grado 
          WHERE a.id_grupo = ?";
if($id_alumno) {
    $query .= " AND a.id_alumno = ?";
}
$query .= " ORDER BY a.nombre";

$stmt = mysqli_prepare($conexion, $query);
if($id_alumno) {
    mysqli_stmt_bind_param($stmt, "ii", $id_grupo, $id_alumno);
} else {
    mysqli_stmt_bind_param($stmt, "i", $id_grupo);
}
mysqli_stmt_execute($stmt);
$resultado_alumnos = mysqli_stmt_get_result($stmt);

while($alumno = mysqli_fetch_assoc($resultado_alumnos)) {
    if($pdf->GetY() > 200) {
        $pdf->AddPage();
    }
    
    // Marco para datos del alumno
    $pdf->SetFillColor(240, 240, 240);
    $pdf->Rect(10, $pdf->GetY(), 190, 30, 'F');
    
    // Información del alumno
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->SetXY(15, $pdf->GetY() + 5);
    $pdf->Cell(30, 6, 'Alumno:', 0, 0);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(60, 6, utf8_decode($alumno['nombre']), 0, 1);
    
    $pdf->SetX(15);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(30, 6, 'Grado y Grupo:', 0, 0);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(60, 6, utf8_decode($alumno['nombre_grado'] . ' - ' . $alumno['nombre_grupo']), 0, 1);
    
    $pdf->SetX(15);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(30, 6, 'Parcial:', 0, 0);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(60, 6, $parcial, 0, 1);
    
    $pdf->Ln(15);

    // Encabezados de la tabla
    $pdf->SetFillColor(0, 48, 135);
    $pdf->SetTextColor(255);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 10, 'MATERIA', 1, 0, 'C', true);
    $pdf->Cell(30, 10, utf8_decode('CALIFICACIÓN'), 1, 1, 'C', true);

    // Obtener calificaciones
    $query_cal = "SELECT m.nombre as materia, c.calificacion 
                  FROM materias m 
                  LEFT JOIN calificaciones c ON m.id_materia = c.id_materia 
                  AND c.id_alumno = ? AND c.parcial = ?
                  WHERE m.id_grado = ?
                  ORDER BY m.nombre";
    $stmt_cal = mysqli_prepare($conexion, $query_cal);
    mysqli_stmt_bind_param($stmt_cal, "iii", $alumno['id_alumno'], $parcial, $id_grado);
    mysqli_stmt_execute($stmt_cal);
    $resultado_cal = mysqli_stmt_get_result($stmt_cal);

    // Contenido de la tabla
    $pdf->SetTextColor(0);
    $pdf->SetFont('Arial', '', 10);
    $suma = 0;
    $count = 0;
    
    while($cal = mysqli_fetch_assoc($resultado_cal)) {
        $pdf->Cell(130, 8, utf8_decode($cal['materia']), 1, 0);
        
        // Color según calificación
        if($cal['calificacion'] < 6) {
            $pdf->SetTextColor(255, 0, 0);
        } elseif($cal['calificacion'] >= 9) {
            $pdf->SetTextColor(0, 128, 0);
        }
        
        $pdf->Cell(30, 8, $cal['calificacion'] ? $cal['calificacion'] : '-', 1, 1, 'C');
        $pdf->SetTextColor(0);
        
        if($cal['calificacion']) {
            $suma += $cal['calificacion'];
            $count++;
        }
    }

    // Promedio
    $pdf->SetFillColor(240, 240, 240);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 10, 'PROMEDIO GENERAL', 1, 0, 'C', true);
    $promedio = $count > 0 ? number_format($suma/$count, 1) : '-';
    $pdf->Cell(30, 10, $promedio, 1, 1, 'C', true);

    // Observaciones
    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 8, 'Observaciones:', 0, 1);
    $pdf->Cell(0, 8, '_____________________________________________________________________________', 0, 1);

    // Firmas
    $pdf->Ln(20);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(95, 5, '______________________', 0, 0, 'C');
    $pdf->Cell(95, 5, '______________________', 0, 1, 'C');
    $pdf->Cell(95, 5, 'Director(a)', 0, 0, 'C');
    $pdf->Cell(95, 5, 'Profesor(a)', 0, 1, 'C');

    if(mysqli_num_rows($resultado_alumnos) > 1) {
        $pdf->AddPage();
    }
}

$pdf->Output('boleta_calificaciones.pdf', 'I');
?>
