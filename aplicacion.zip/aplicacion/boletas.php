<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener lista de grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);

// Obtener el parcial seleccionado (por defecto el 1)
$parcial = isset($_GET['parcial']) ? $_GET['parcial'] : 1;

// Obtener grado y grupo seleccionados
$id_grado = isset($_GET['grado']) ? $_GET['grado'] : null;
$id_grupo = isset($_GET['grupo']) ? $_GET['grupo'] : null;

// Obtener grupos si se seleccionó un grado
$resultado_grupos = null;
if($id_grado) {
    // Consulta directa para debug
    $query_grupos = "SELECT * FROM grupos WHERE id_grado = $id_grado ORDER BY nombre";
    $resultado_grupos = mysqli_query($conexion, $query_grupos);
    
    // Debug
    if (!$resultado_grupos) {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }
}

// Obtener alumnos si se seleccionó un grupo
if($id_grupo) {
    $query_alumnos = "SELECT * FROM alumnos WHERE id_grupo = ? ORDER BY nombre";
    $stmt = mysqli_prepare($conexion, $query_alumnos);
    mysqli_stmt_bind_param($stmt, "i", $id_grupo);
    mysqli_stmt_execute($stmt);
    $resultado_alumnos = mysqli_stmt_get_result($stmt);
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Boletas de Calificaciones</h6>
                </div>
                <div class="card-body">
                    <!-- Filtros -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label class="form-label">Grado</label>
                            <select class="form-select" id="selectGrado">
                                <option value="">Seleccionar Grado</option>
                                <?php while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                    <option value="<?php echo $grado['id_grado']; ?>" 
                                            <?php echo ($id_grado == $grado['id_grado']) ? 'selected' : ''; ?>>
                                        <?php echo $grado['nombre']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Grupo</label>
                            <select class="form-select" id="selectGrupo">
                                <option value="">Seleccionar Grupo</option>
                                <?php 
                                if($resultado_grupos && mysqli_num_rows($resultado_grupos) > 0) {
                                    while($grupo = mysqli_fetch_assoc($resultado_grupos)) { ?>
                                        <option value="<?php echo $grupo['id_grupo']; ?>"
                                                <?php echo ($id_grupo == $grupo['id_grupo']) ? 'selected' : ''; ?>>
                                            <?php echo $grupo['nombre']; ?>
                                        </option>
                                <?php }
                                } ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de Boleta</label>
                            <select class="form-select" id="selectParcial">
                                <option value="1" <?php echo $parcial == 1 ? 'selected' : ''; ?>>Primer Parcial</option>
                                <option value="2" <?php echo $parcial == 2 ? 'selected' : ''; ?>>Segundo Parcial</option>
                                <option value="3" <?php echo $parcial == 3 ? 'selected' : ''; ?>>Tercer Parcial</option>
                                <option value="final" <?php echo $parcial == 'final' ? 'selected' : ''; ?>>Boleta Final</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button class="btn btn-primary" id="generarBoleta">
                                <i class="fas fa-print"></i> Generar Boleta
                            </button>
                        </div>
                    </div>

                    <!-- Debug info -->
                    <?php if($id_grado) { ?>
                        <div class="alert alert-info">
                            Grado seleccionado: <?php echo $id_grado; ?><br>
                            Número de grupos: <?php echo $resultado_grupos ? mysqli_num_rows($resultado_grupos) : 0; ?>
                        </div>
                    <?php } ?>

                    <!-- Vista previa de alumnos -->
                    <?php if($id_grupo && isset($resultado_alumnos)) { ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Alumno</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($alumno = mysqli_fetch_assoc($resultado_alumnos)) { ?>
                                        <tr>
                                            <td><?php echo $alumno['nombre']; ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info generarBoletaIndividual" 
                                                        data-alumno="<?php echo $alumno['id_alumno']; ?>">
                                                    <i class="fas fa-print"></i> Generar Boleta Individual
                                                </button>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        <div class="text-center py-4">
                            <p>Selecciona un grado y grupo para ver la lista de alumnos</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Manejar cambio de grado
    $('#selectGrado').change(function() {
        const gradoId = $(this).val();
        if(gradoId) {
            window.location.href = 'boletas.php?grado=' + gradoId;
        } else {
            window.location.href = 'boletas.php';
        }
    });

    // Manejar cambio de grupo
    $('#selectGrupo').change(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $(this).val();
        const parcial = $('#selectParcial').val();
        if(grupoId) {
            window.location.href = 'boletas.php?grado=' + gradoId + '&grupo=' + grupoId + '&parcial=' + parcial;
        }
    });

    // Manejar cambio de parcial
    $('#selectParcial').change(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $('#selectGrupo').val();
        const parcial = $(this).val();
        if(grupoId) {
            window.location.href = 'boletas.php?grado=' + gradoId + '&grupo=' + grupoId + '&parcial=' + parcial;
        }
    });

    // Generar boleta grupal
    $('#generarBoleta').click(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $('#selectGrupo').val();
        const parcial = $('#selectParcial').val();
        
        if(grupoId) {
            if(parcial === 'final') {
                window.open('generar_boleta_final.php?grado=' + gradoId + '&grupo=' + grupoId, '_blank');
            } else {
                window.open('generar_boleta.php?grado=' + gradoId + '&grupo=' + grupoId + 
                           '&parcial=' + parcial, '_blank');
            }
        }
    });

    // Generar boleta individual
    $('.generarBoletaIndividual').click(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $('#selectGrupo').val();
        const parcial = $('#selectParcial').val();
        const alumnoId = $(this).data('alumno');
        
        if(parcial === 'final') {
            window.open('generar_boleta_final.php?grado=' + gradoId + '&grupo=' + grupoId + 
                       '&alumno=' + alumnoId, '_blank');
        } else {
            window.open('generar_boleta.php?grado=' + gradoId + '&grupo=' + grupoId + 
                       '&parcial=' + parcial + '&alumno=' + alumnoId, '_blank');
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?> 