{
    "require": {
        "phpoffice/phpspreadsheet": "^1.18",
        "fpdf/fpdf": "^1.84"
    }
} 