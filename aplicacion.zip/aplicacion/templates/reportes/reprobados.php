<?php
if (!isset($info) || !isset($materias) || !isset($datos)) {
    die('Variables no definidas');
}
?>
<div class="table-responsive">
    <h4 class="mb-3">Reporte de Alumnos Reprobados</h4>
    <h5 class="mb-3"><?php echo htmlspecialchars($info['grado']) . ' - Grupo ' . htmlspecialchars($info['grupo']); ?></h5>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Alumno</th>
                <th>Materias Reprobadas</th>
                <th>Promedio General</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $reprobados = false;
            foreach($datos as $dato): 
                $materias_reprobadas = [];
                foreach($materias as $materia) {
                    if(isset($dato['calificaciones'][$materia['id_materia']]) && 
                       $dato['calificaciones'][$materia['id_materia']] < 6) {
                        $materias_reprobadas[] = $materia['nombre'];
                    }
                }
                if(!empty($materias_reprobadas)):
                    $reprobados = true;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($dato['alumno']['nombre']); ?></td>
                    <td>
                        <ul class="mb-0">
                            <?php foreach($materias_reprobadas as $materia): ?>
                                <li><?php echo htmlspecialchars($materia); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </td>
                    <td><?php echo number_format($dato['promedio'], 2); ?></td>
                </tr>
            <?php 
                endif;
            endforeach; 
            if(!$reprobados):
            ?>
                <tr>
                    <td colspan="3" class="text-center">No hay alumnos reprobados</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div> 