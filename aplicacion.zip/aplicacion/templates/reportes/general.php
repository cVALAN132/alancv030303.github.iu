<?php
// Verificar que tenemos todas las variables necesarias
if (!isset($info) || !isset($materias) || !isset($datos)) {
    echo '<div class="alert alert-danger">Error: Datos no disponibles para generar el reporte.</div>';
    return;
}
?>
<div class="table-responsive">
    <h4 class="mb-3">Reporte General de Calificaciones</h4>
    <h5 class="mb-3"><?php echo htmlspecialchars($info['grado']) . ' - Grupo ' . htmlspecialchars($info['grupo']); ?></h5>
    
    <?php if (empty($datos)): ?>
        <div class="alert alert-info">No hay datos disponibles para mostrar.</div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Alumno</th>
                    <?php foreach($materias as $materia): ?>
                        <th><?php echo htmlspecialchars($materia['nombre']); ?></th>
                    <?php endforeach; ?>
                    <th>Promedio</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($datos as $dato): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($dato['alumno']['nombre']); ?></td>
                        <?php foreach($materias as $materia): ?>
                            <td>
                                <?php 
                                    $calificacion = isset($dato['calificaciones'][$materia['id_materia']]) 
                                        ? $dato['calificaciones'][$materia['id_materia']] 
                                        : '-';
                                    echo is_numeric($calificacion) ? number_format($calificacion, 1) : $calificacion;
                                ?>
                            </td>
                        <?php endforeach; ?>
                        <td><?php echo number_format($dato['promedio'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div> 