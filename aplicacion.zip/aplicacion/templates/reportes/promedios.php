<?php
if (!isset($info) || !isset($datos)) {
    die('Variables no definidas');
}
?>
<div class="table-responsive">
    <h4 class="mb-3">Reporte de Promedios</h4>
    <h5 class="mb-3"><?php echo htmlspecialchars($info['grado']) . ' - Grupo ' . htmlspecialchars($info['grupo']); ?></h5>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Alumno</th>
                <th>Promedio General</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($datos as $dato): ?>
                <tr>
                    <td><?php echo htmlspecialchars($dato['alumno']['nombre']); ?></td>
                    <td><?php echo number_format($dato['promedio'], 2); ?></td>
                    <td>
                        <?php if($dato['promedio'] >= 6): ?>
                            <span class="badge bg-success">Aprobado</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Reprobado</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div> 