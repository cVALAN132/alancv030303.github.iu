<?php
require_once 'config/conexion.php';
require_once 'config/config.php';
include 'includes/header.php';

// Configuración de paginación
$por_pagina = 10;
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina - 1) * $por_pagina;

// Consulta para obtener el total de registros
$sql_total = "SELECT COUNT(*) as total FROM alumnos";
$resultado_total = mysqli_query($conexion, $sql_total);
$data_total = mysqli_fetch_assoc($resultado_total);
$total_registros = $data_total['total'];
$total_paginas = ceil($total_registros / $por_pagina);

// Consulta paginada
$query = "SELECT * FROM alumnos ORDER BY nombre ASC LIMIT $inicio, $por_pagina";
$resultado = mysqli_query($conexion, $query);
?>

<div class="row fade-in">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-users me-2"></i>Gestión de Alumnos</h2>
            <div>
                <button class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#modalImportar">
                    <i class="fas fa-file-excel me-2"></i>Importar Alumnos
                </button>
                <a href="alumno_nuevo.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Nuevo Alumno
                </a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Matrícula</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Fecha Registro</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($alumno = mysqli_fetch_assoc($resultado)): ?>
                            <tr>
                                <td><?php echo $alumno['matricula']; ?></td>
                                <td><?php echo $alumno['nombre']; ?></td>
                                <td><?php echo $alumno['email']; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($alumno['fecha_registro'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-warning me-2 btn-editar" 
                                            data-id="<?php echo $alumno['id_alumno']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger eliminar-alumno" 
                                            data-id="<?php echo $alumno['id_alumno']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if($pagina > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina - 1; ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php
                        $rango = 2;
                        for($i = max(1, $pagina - $rango); $i <= min($total_paginas, $pagina + $rango); $i++): ?>
                            <li class="page-item <?php echo ($i == $pagina) ? 'active' : ''; ?>">
                                <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if($pagina < $total_paginas): ?>
                            <li class="page-item">
                                <a class="page-link" href="?pagina=<?php echo $pagina + 1; ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>

                <!-- Información de registros -->
                <div class="text-muted text-center mt-2">
                    Mostrando registros <?php echo $inicio + 1; ?> - 
                    <?php echo min($inicio + $por_pagina, $total_registros); ?> 
                    de <?php echo $total_registros; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Agregar estilos para la paginación -->
<style>
.pagination .page-link {
    color: #333;
    border-radius: 3px;
    margin: 0 2px;
}

.pagination .page-item.active .page-link {
    background-color: #0d6efd;
    border-color: #0d6efd;
    color: white;
}

.pagination .page-link:hover {
    background-color: #e9ecef;
    border-color: #dee2e6;
    color: #0d6efd;
}

.pagination .page-item:first-child .page-link,
.pagination .page-item:last-child .page-link {
    padding: 0.5rem 0.75rem;
}
</style>

<?php include 'includes/footer.php'; ?>

<?php if(isset($_GET['mensaje']) && $_GET['mensaje'] == 'actualizado'): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: '¡Éxito!',
            text: 'El alumno ha sido actualizado correctamente',
            timer: 2000,
            showConfirmButton: false
        });
    </script>
<?php endif; ?> 

<script>
$(document).ready(function() {
    // Función para cargar datos del alumno en el modal
    $('.btn-editar').click(function() {
        var id = $(this).data('id');
        $.ajax({
            url: 'actions/get_alumno.php',
            type: 'POST',
            data: {id: id},
            dataType: 'json',
            success: function(data) {
                $('#edit_id_alumno').val(data.id_alumno);
                $('#edit_matricula').val(data.matricula);
                $('#edit_nombre').val(data.nombre);
                $('#edit_email').val(data.email);
                $('#modalEditar').modal('show');
            }
        });
    });

    // Función para eliminar alumno
    $('.eliminar-alumno').click(function() {
        var id = $(this).data('id');
        Swal.fire({
            title: '¿Estás seguro?',
            text: "Esta acción no se puede deshacer",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'actions/eliminar_alumno.php',
                    type: 'POST',
                    data: {id: id},
                    dataType: 'json',
                    success: function(response) {
                        if(response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: '¡Eliminado!',
                                text: 'El alumno ha sido eliminado.',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    }
                });
            }
        });
    });

    // Manejar el envío del formulario de edición
    $('#formEditar').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: 'actions/actualizar_alumno.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.status === 'success') {
                    $('#modalEditar').modal('hide');
                    Swal.fire({
                        icon: 'success',
                        title: '¡Actualizado!',
                        text: 'El alumno ha sido actualizado correctamente',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            }
        });
    });

    // Manejar la importación de alumnos
    $('#formImportar').submit(function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        
        Swal.fire({
            title: 'Procesando...',
            text: 'Por favor espere mientras se importan los alumnos',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/importar_alumnos.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                try {
                    var result = JSON.parse(response);
                    if(result.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Éxito!',
                            text: result.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire('Error', result.message, 'error');
                    }
                } catch(e) {
                    Swal.fire('Error', 'Error al procesar la respuesta', 'error');
                }
            },
            error: function() {
                Swal.fire('Error', 'Error al procesar la solicitud', 'error');
            }
        });
    });
});
</script>

<!-- Modal de Edición -->
<div class="modal fade" id="modalEditar" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Alumno</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formEditar">
                    <input type="hidden" id="edit_id_alumno" name="id_alumno">
                    <div class="mb-3">
                        <label class="form-label">Matrícula</label>
                        <input type="text" class="form-control" id="edit_matricula" name="matricula" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="edit_nombre" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Importación -->
<div class="modal fade" id="modalImportar" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importar Alumnos</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formImportar" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Seleccionar archivo Excel</label>
                        <input type="file" class="form-control" name="archivo" accept=".xlsx,.xls" required>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            El archivo debe ser Excel (.xlsx, .xls) y contener las columnas: Matrícula, Nombre, Email
                        </small>
                    </div>
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-upload me-2"></i>Importar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> 