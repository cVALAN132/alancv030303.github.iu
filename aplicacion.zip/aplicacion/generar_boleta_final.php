<?php
require_once 'config/conexion.php';
require_once 'vendor/fpdf/fpdf/src/Fpdf/Fpdf.php';

use Fpdf\Fpdf;

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 10, 'BOLETA FINAL DE CALIFICACIONES', 0, 1, 'C');
        $this->Ln(10);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Página '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }
}

// Obtener parámetros
$id_grado = isset($_GET['grado']) ? $_GET['grado'] : null;
$id_grupo = isset($_GET['grupo']) ? $_GET['grupo'] : null;
$id_alumno = isset($_GET['alumno']) ? $_GET['alumno'] : null;

if(!$id_grado || !$id_grupo) {
    die('Parámetros incompletos');
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Obtener información del alumno
$query = "SELECT a.*, g.nombre as nombre_grado, gr.nombre as nombre_grupo 
          FROM alumnos a 
          JOIN grupos gr ON a.id_grupo = gr.id_grupo 
          JOIN grados g ON gr.id_grado = g.id_grado 
          WHERE a.id_grupo = ?";
if($id_alumno) {
    $query .= " AND a.id_alumno = ?";
}
$query .= " ORDER BY a.nombre";

$stmt = mysqli_prepare($conexion, $query);
if($id_alumno) {
    mysqli_stmt_bind_param($stmt, "ii", $id_grupo, $id_alumno);
} else {
    mysqli_stmt_bind_param($stmt, "i", $id_grupo);
}
mysqli_stmt_execute($stmt);
$resultado_alumnos = mysqli_stmt_get_result($stmt);

while($alumno = mysqli_fetch_assoc($resultado_alumnos)) {
    if($pdf->GetY() > 250) {
        $pdf->AddPage();
    }

    // Información del alumno
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Alumno: ' . utf8_decode($alumno['nombre']), 0, 1);
    $pdf->Cell(0, 10, 'Grado: ' . utf8_decode($alumno['nombre_grado'] . ' - Grupo: ' . $alumno['nombre_grupo']), 0, 1);
    $pdf->Ln(5);

    // Encabezados de la tabla
    $pdf->SetFillColor(232, 232, 232);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(60, 8, 'MATERIA', 1, 0, 'C', true);
    $pdf->Cell(25, 8, '1er PARCIAL', 1, 0, 'C', true);
    $pdf->Cell(25, 8, '2do PARCIAL', 1, 0, 'C', true);
    $pdf->Cell(25, 8, '3er PARCIAL', 1, 0, 'C', true);
    $pdf->Cell(30, 8, 'PROMEDIO', 1, 1, 'C', true);

    // Obtener calificaciones
    $query_materias = "SELECT m.nombre as materia, 
           MAX(CASE WHEN c.parcial = 1 THEN c.calificacion END) as parcial1,
           MAX(CASE WHEN c.parcial = 2 THEN c.calificacion END) as parcial2,
           MAX(CASE WHEN c.parcial = 3 THEN c.calificacion END) as parcial3
    FROM materias m 
    LEFT JOIN calificaciones c ON m.id_materia = c.id_materia 
    AND c.id_alumno = ?
    WHERE m.id_grado = ?
    GROUP BY m.id_materia, m.nombre
    ORDER BY m.nombre";
    
    $stmt = mysqli_prepare($conexion, $query_materias);
    mysqli_stmt_bind_param($stmt, "ii", $alumno['id_alumno'], $id_grado);
    mysqli_stmt_execute($stmt);
    $resultado_materias = mysqli_stmt_get_result($stmt);

    $pdf->SetFont('Arial', '', 10);
    $promedio_general = 0;
    $materias_count = 0;

    while($materia = mysqli_fetch_assoc($resultado_materias)) {
        $promedio = 0;
        $count = 0;
        if($materia['parcial1']) { $promedio += $materia['parcial1']; $count++; }
        if($materia['parcial2']) { $promedio += $materia['parcial2']; $count++; }
        if($materia['parcial3']) { $promedio += $materia['parcial3']; $count++; }
        $promedio_final = $count > 0 ? $promedio / $count : 0;

        if($count > 0) {
            $promedio_general += $promedio_final;
            $materias_count++;
        }

        $pdf->Cell(60, 8, utf8_decode($materia['materia']), 1, 0);
        $pdf->Cell(25, 8, $materia['parcial1'] ?: '-', 1, 0, 'C');
        $pdf->Cell(25, 8, $materia['parcial2'] ?: '-', 1, 0, 'C');
        $pdf->Cell(25, 8, $materia['parcial3'] ?: '-', 1, 0, 'C');
        $pdf->Cell(30, 8, $count > 0 ? number_format($promedio_final, 1) : '-', 1, 1, 'C');
    }

    // Promedio General
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(135, 8, 'PROMEDIO GENERAL', 1, 0, 'R');
    $pdf->Cell(30, 8, $materias_count > 0 ? number_format($promedio_general / $materias_count, 1) : '-', 1, 1, 'C');

    // Firmas
    $pdf->Ln(20);
    $pdf->Cell(63, 5, '______________________', 0, 0, 'C');
    $pdf->Cell(63, 5, '______________________', 0, 0, 'C');
    $pdf->Cell(63, 5, '______________________', 0, 1, 'C');
    
    $pdf->Cell(63, 5, 'Director(a)', 0, 0, 'C');
    $pdf->Cell(63, 5, 'Profesor(a)', 0, 0, 'C');
    $pdf->Cell(63, 5, 'Padre o Tutor', 0, 1, 'C');

    if(mysqli_num_rows($resultado_alumnos) > 1) {
        $pdf->AddPage();
    }
}

$pdf->Output('boleta_final.pdf', 'I');
?> 