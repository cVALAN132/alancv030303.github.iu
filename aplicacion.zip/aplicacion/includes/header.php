<?php
require_once 'session.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Académico</title>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #059669;
            --danger: #dc2626;
            --warning: #d97706;
            --info: #0284c7;
            --light: #f1f5f9;
            --dark: #0f172a;
            --sidebar-width: 250px;
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #f8fafc;
            min-height: 100vh;
        }

        .wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar mejorado */
        #sidebar {
            width: var(--sidebar-width);
            background: var(--dark);
            position: fixed;
            height: 100vh;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-logo {
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
        }

        .logo-icon i {
            font-size: 1.5rem;
            color: white;
        }

        .sidebar-logo span {
            color: white;
            font-size: 1.25rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        /* Efecto hover */
        .logo-icon:hover {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }

        .sidebar-menu {
            padding: 1rem 0;
        }

        .menu-header {
            color: #94a3b8;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 1.25rem 1.5rem 0.5rem;
        }

        .menu-item {
            padding: 0.25rem 1rem;
        }

        .menu-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: #e2e8f0;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .menu-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            transform: translateX(4px);
        }

        .menu-link.active {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
        }

        .menu-icon {
            width: 1.5rem;
            margin-right: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }

        /* Navbar superior mejorado */
        .top-navbar {
            height: 70px;
            background: white;
            padding: 0 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .menu-toggle {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 1.25rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .menu-toggle:hover {
            background: var(--light);
            color: var(--primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-menu {
            position: relative;
            padding: 0.5rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .user-menu:hover {
            background-color: var(--light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1.1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .user-avatar-sm {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .user-info {
            display: block;
        }

        .user-name {
            font-weight: 600;
            color: var(--dark);
            font-size: 0.95rem;
            margin-bottom: -4px;
        }

        .user-role {
            color: var(--secondary);
            font-size: 0.8rem;
        }

        .user-dropdown {
            min-width: 240px;
            padding: 0.5rem;
            border: none;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            margin-top: 10px;
        }

        .dropdown-header {
            background: var(--light);
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 0.5rem;
        }

        .dropdown-item {
            padding: 0.7rem 1rem;
            border-radius: 6px;
            transition: all 0.2s;
        }

        .dropdown-item:hover {
            background-color: var(--light);
            transform: translateX(5px);
        }

        .dropdown-item i {
            width: 20px;
            text-align: center;
        }

        .dropdown-divider {
            margin: 0.5rem 0;
        }

        /* Contenido principal */
        #content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: all 0.3s ease;
        }

        /* Responsive */
        @media (max-width: 768px) {
            #sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
            }

            #sidebar.active {
                margin-left: 0;
            }

            #content {
                margin-left: 0;
            }

            .top-navbar {
                padding: 0 1rem;
            }

            .user-info {
                display: none;
            }
            
            .user-dropdown {
                min-width: 200px;
            }
        }

        .user-dropdown-btn {
            background: none;
            border: none;
            padding: 0.5rem;
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .user-dropdown-btn:focus {
            outline: none;
            box-shadow: none;
        }

        .user-dropdown-btn::after {
            display: none;
        }

        .user-menu .dropdown-menu {
            margin-top: 0.5rem;
            border-radius: 8px;
            border: none;
            box-shadow: 0 0 20px rgba(0,0,0,0.15);
            padding: 0.5rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #0061f2 0%, #00ba88 100%);
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .user-info {
            margin-left: 10px;
            text-align: left;
        }

        .user-name {
            font-weight: 600;
            color: #333;
        }

        .user-role small {
            color: #666;
        }

        .dropdown-item {
            padding: 0.5rem 1rem;
            border-radius: 4px;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
        }

        .dropdown-header {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 4px;
        }

        .user-avatar-sm {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #0061f2 0%, #00ba88 100%);
            color: white;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="sidebar-logo">
                <div class="logo-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <span>sistema Academico</span>
            </div>

            <div class="sidebar-menu">
                <div class="menu-header">Principal</div>
                <div class="menu-item">
                    <a href="dashboard.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-chart-line"></i>
                        </span>
                        <span>Dashboard</span>
                    </a>
                </div>

                <div class="menu-header">Gestión Académica</div>
                <div class="menu-item">
                    <a href="grados_grupos.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'grados_grupos.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-school"></i>
                        </span>
                        <span>Grados y Grupos</span>
                    </a>
                </div>

                <div class="menu-item">
                    <a href="materias.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'materias.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-book"></i>
                        </span>
                        <span>Materias</span>
                    </a>
                </div>

                <div class="menu-header">Evaluación</div>
                <div class="menu-item">
                    <a href="calificaciones.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'calificaciones.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-star"></i>
                        </span>
                        <span>Calificaciones</span>
                    </a>
                </div>

                <div class="menu-item">
                    <a href="boletas.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'boletas.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-file-alt"></i>
                        </span>
                        <span>Boletas</span>
                    </a>
                </div>

                <div class="menu-item">
                    <a href="reportes.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'reportes.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-file-alt"></i>
                        </span>
                        <span>Reportes</span>
                    </a>
                </div>

                <div class="menu-item">
                    <a href="enviar_boletas.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'enviar_boletas.php' ? 'active' : ''; ?>">
                        <span class="menu-icon">
                            <i class="fas fa-envelope"></i>
                        </span>
                        <span>Enviar Boletas</span>
                    </a>
                </div>
            </div>
        </nav>

        <div id="content">
            <nav class="top-navbar">
                <div class="nav-left">
                    <button class="menu-toggle" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="mb-0 d-none d-md-block">Sistema de Gestión Académica</h4>
                </div>

                <div class="nav-right">
                    <div class="user-menu">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle user-dropdown-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div class="d-flex align-items-center">
                                    <div class="user-avatar">
                                        <?php echo substr($_SESSION['nombre'], 0, 1); ?>
                                    </div>
                                    <div class="user-info ms-2">
                                        <div class="user-name"><?php echo $_SESSION['nombre']; ?></div>
                                        <div class="user-role">
                                            <small>Administrador</small>
                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                <div class="dropdown-header">
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar-sm me-3">
                                            <?php echo substr($_SESSION['nombre'], 0, 1); ?>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo $_SESSION['nombre']; ?></h6>
                                            <small class="text-muted">Administrador</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="perfil.php">
                                    <i class="fas fa-user me-2 text-primary"></i>
                                    Mi Perfil
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

            <div class="container-fluid p-4">
            <!-- Contenido de la página -->

<script>
$(document).ready(function() {
    $('#sidebarToggle').click(function() {
        $('#sidebar').toggleClass('active');
    });

    $('.dropdown-toggle').click(function(e) {
        e.preventDefault();
        $(this).parent().toggleClass('show');
        $(this).next('.dropdown-menu').toggleClass('show');
    });

    $(document).click(function(e) {
        if (!$(e.target).closest('.dropdown').length) {
            $('.dropdown-menu').removeClass('show');
            $('.dropdown').removeClass('show');
        }
    });
});
</script>
</body>
</html>