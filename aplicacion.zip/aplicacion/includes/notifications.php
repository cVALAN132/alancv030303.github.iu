<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function enviarNotificacion($para, $asunto, $mensaje) {
    $mail = new PHPMailer(true);
    
    try {
        //Configuración del servidor
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';

        //Destinatarios
        $mail->setFrom(MAIL_USER, SITE_NAME);
        $mail->addAddress($para);

        //Contenido
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body    = $mensaje;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Error al enviar correo: {$mail->ErrorInfo}");
        return false;
    }
}

// Ejemplo de uso:
/*
enviarNotificacion(
    'destinatario@ejemplo.com',
    'Asunto del correo',
    'Contenido del correo en <b>HTML</b>'
);
*/
?> 