<?php
function registrarError($error) {
    $fecha = date('Y-m-d H:i:s');
    $mensaje = "[$fecha] $error\n";
    error_log($mensaje, 3, "logs/error.log");
}

function mostrarMensaje($tipo, $mensaje) {
    return "<div class='alert alert-$tipo alert-dismissible fade show'>
                $mensaje
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            </div>";
} 