<?php
require_once 'config/conexion.php';
include 'includes/header.php';

if(isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conexion, $_GET['id']);
    $query = "SELECT * FROM alumnos WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $alumno = mysqli_fetch_assoc($resultado);
    
    if(!$alumno) {
        header('Location: alumnos.php');
        exit;
    }
} else {
    header('Location: alumnos.php');
    exit;
}

// Procesar el formulario de edición
if(isset($_POST['editar'])) {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    $matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);
    
    $query = "UPDATE alumnos SET nombre = ?, email = ?, matricula = ? WHERE id_alumno = ?";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $nombre, $email, $matricula, $id);
    
    if(mysqli_stmt_execute($stmt)) {
        header('Location: alumnos.php?mensaje=actualizado');
        exit;
    }
}
?>

<div class="row fade-in">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-user-edit me-2"></i>Editar Alumno</h2>
            <a href="alumnos.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Volver
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="matricula" class="form-label">Matrícula</label>
                        <input type="text" class="form-control" id="matricula" name="matricula" 
                               value="<?php echo $alumno['matricula']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre Completo</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" 
                               value="<?php echo $alumno['nombre']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo $alumno['email']; ?>" required>
                    </div>
                    
                    <button type="submit" name="editar" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Guardar Cambios
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.eliminar-alumno').click(function() {
        const id = $(this).data('id');
        
        Swal.fire({
            title: '¿Estás seguro?',
            text: "Esta acción no se puede deshacer",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'actions/eliminar_alumno.php',
                    type: 'POST',
                    data: {id: id},
                    dataType: 'json',
                    success: function(response) {
                        if(response.status === 'success') {
                            Swal.fire(
                                '¡Eliminado!',
                                'El alumno ha sido eliminado.',
                                'success'
                            ).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire(
                                'Error',
                                response.message,
                                'error'
                            );
                        }
                    },
                    error: function() {
                        Swal.fire(
                            'Error',
                            'Ocurrió un error al procesar la solicitud',
                            'error'
                        );
                    }
                });
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?> 