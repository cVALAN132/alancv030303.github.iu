<?php
require_once 'includes/header.php';
require_once 'config/conexion.php';

// Obtener datos del usuario actual
$id_usuario = $_SESSION['id_usuario'];
$query = "SELECT * FROM usuarios WHERE id_usuario = ?";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "i", $id_usuario);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$usuario = mysqli_fetch_assoc($resultado);
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-circle me-2"></i>
                        Mi Perfil
                    </h5>
                </div>
                <div class="card-body">
                    <form id="formEditarPerfil">
                        <input type="hidden" name="id_usuario" value="<?php echo $id_usuario; ?>">
                        
                        <div class="row mb-4">
                            <div class="col-auto">
                                <div class="avatar-preview" style="width: 100px; height: 100px; background: linear-gradient(135deg, #0061f2 0%, #00ba88 100%); border-radius: 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 2.5rem; font-weight: bold;">
                                    <?php echo substr($usuario['nombre'], 0, 1); ?>
                                </div>
                            </div>
                            <div class="col d-flex align-items-center">
                                <div>
                                    <h4 class="mb-1"><?php echo $usuario['nombre']; ?></h4>
                                    <p class="text-muted mb-0">
                                        <i class="fas fa-user-shield me-1"></i>
                                        Administrador
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nombre Completo</label>
                            <input type="text" class="form-control" name="nombre" value="<?php echo $usuario['nombre']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Usuario</label>
                            <input type="text" class="form-control" name="usuario" value="<?php echo $usuario['usuario']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nueva Contraseña</label>
                            <input type="password" class="form-control" name="password" placeholder="Dejar en blanco para mantener la actual">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Confirmar Nueva Contraseña</label>
                            <input type="password" class="form-control" name="confirmar_password" placeholder="Confirmar nueva contraseña">
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Guardar Cambios
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#formEditarPerfil').on('submit', function(e) {
        e.preventDefault();
        
        // Validar contraseñas
        let password = $('input[name="password"]').val();
        let confirmar = $('input[name="confirmar_password"]').val();
        
        if(password && password !== confirmar) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Las contraseñas no coinciden'
            });
            return;
        }
        
        Swal.fire({
            title: 'Actualizando...',
            text: 'Por favor espere',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'actions/usuarios/actualizar_perfil.php',
            method: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: 'Perfil actualizado correctamente',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            }
        });
    });
});
</script> 