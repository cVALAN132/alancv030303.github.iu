<?php
include 'includes/header.php';
require_once 'config/conexion.php';

// Obtener grados
$query_grados = "SELECT * FROM grados ORDER BY nombre";
$resultado_grados = mysqli_query($conexion, $query_grados);
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>Reportes de Calificaciones</h6>
                </div>
                <div class="card-body">
                    <!-- Filtros -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label class="form-label">Grado</label>
                            <select class="form-select" id="selectGrado">
                                <option value="">Seleccionar Grado</option>
                                <?php while($grado = mysqli_fetch_assoc($resultado_grados)) { ?>
                                    <option value="<?php echo $grado['id_grado']; ?>">
                                        <?php echo $grado['nombre']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Grupo</label>
                            <select class="form-select" id="selectGrupo" disabled>
                                <option value="">Seleccionar Grupo</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de Reporte</label>
                            <select class="form-select" id="tipoReporte">
                                <option value="general">Reporte General</option>
                                <option value="promedios">Promedios</option>
                                <option value="reprobados">Alumnos Reprobados</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">&nbsp;</label>
                            <button class="btn btn-primary d-block" id="generarReporte">
                                <i class="fas fa-file-pdf"></i> Generar Reporte
                            </button>
                        </div>
                    </div>

                    <!-- Vista previa del reporte -->
                    <div id="vistaPrevia" class="mt-4">
                        <!-- Aquí se cargará la vista previa del reporte -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Manejar cambio de grado
    $('#selectGrado').change(function() {
        const gradoId = $(this).val();
        const grupoSelect = $('#selectGrupo');
        
        if(gradoId) {
            $.get('actions/grupos/obtener_grupos.php', {id_grado: gradoId}, function(response) {
                if(response.success) {
                    grupoSelect.html('<option value="">Seleccionar Grupo</option>');
                    response.grupos.forEach(function(grupo) {
                        grupoSelect.append(`<option value="${grupo.id_grupo}">${grupo.nombre}</option>`);
                    });
                    grupoSelect.prop('disabled', false);
                }
            }, 'json');
        } else {
            grupoSelect.html('<option value="">Seleccionar Grupo</option>');
            grupoSelect.prop('disabled', true);
        }
    });

    // Generar reporte
    $('#generarReporte').click(function() {
        const gradoId = $('#selectGrado').val();
        const grupoId = $('#selectGrupo').val();
        const tipoReporte = $('#tipoReporte').val();

        if(!gradoId || !grupoId) {
            Swal.fire({
                icon: 'warning',
                title: 'Atención',
                text: 'Por favor selecciona un grado y un grupo'
            });
            return;
        }

        // Mostrar loading
        Swal.fire({
            title: 'Generando reporte',
            text: 'Por favor espere...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Generar reporte
        $.get('actions/reportes/generar_reporte.php', {
            grado: gradoId,
            grupo: grupoId,
            tipo: tipoReporte
        }, function(response) {
            Swal.close();
            if(response.success) {
                $('#vistaPrevia').html(response.html);
                
                // Botón para descargar PDF
                Swal.fire({
                    icon: 'success',
                    title: '¡Reporte generado!',
                    text: '¿Deseas descargar el PDF?',
                    showCancelButton: true,
                    confirmButtonText: 'Descargar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'actions/reportes/descargar_pdf.php?' + 
                            $.param({grado: gradoId, grupo: grupoId, tipo: tipoReporte});
                    }
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message
                });
            }
        }, 'json');
    });
});
</script>

<?php include 'includes/footer.php'; ?> 